package com.legreenfee.legreenfeesdk;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LGFFBookingActivity extends AppCompatActivity {

    private String mClubId;
    private String mClubName;
    private ArrayList<LGFFCourse> mCourses;
    private ArrayList<LGFFDiscount> mDiscounts;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog dateDialog;
    private LinearLayout date_layout_button;
    private TextView dateLabel;
    private LinearLayout players_layout_button;
    private TextView players_label;
    private LinearLayout course_picker_button;
    private TextView course_name_label;
    private LinearLayout discount_picker_button;
    private LinearLayout discount_picker_button_divider;
    private TextView discount_label;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private TeeTimesAdapter mAdapter;
    private LinearLayout loadingLayout;
    private LinearLayout emptyLayout;
    private Date selectedDate;
    private Locale currentLocale;
    private ArrayList<String> teePublicIds;
    private String selectedTeePublicId;
    private ArrayList<String> discountPublicIds;
    private String selectedDiscountId;
    private int courseIterator = 0;
    private ArrayList<String> courseNames;
    private NumberPicker courseNumberPicker;
    private LGFFTeeTime selectedTeeTime;
    private int playersNumber = 1;
    private String selectedTeeName;
    private Toolbar toolbar;
    private LinearLayout loadingOverlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lgffbooking);

        //  if(MyGreenFeeKit.getDelegate() == null) {
        //          throw new Exception("Host must implement non null delegate");
        //  }

        Bundle b = getIntent().getExtras();
        mClubId = b.getString("club_id");
        mClubName = b.getString("club_name");
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(mClubName);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        selectedDate = (MyGreenFeeKit.getDelegate().getDefaultDate());
        selectedDiscountId = (MyGreenFeeKit.getDelegate().getDefaultDiscountId());

        loadingLayout = (LinearLayout) findViewById(R.id.loading_layout);
        loadingOverlay = (LinearLayout) findViewById(R.id.loading_overlay);
        loadingOverlay.setVisibility(View.GONE);
        loadingOverlay.setOnTouchListener(new View.OnTouchListener(){

                                              @Override
                                              public boolean onTouch(View v, MotionEvent event) {
                                                  return true;
                                              }
                                          }
        );
        emptyLayout = (LinearLayout) findViewById(R.id.empty_layout);

        ImageView calendarIcon = (ImageView) findViewById(R.id.calendar_icon);
        Drawable normalDrawable = getResources().getDrawable(R.drawable.ic_today_black_48dp);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, getResources().getColor(R.color.colorPrimary));
        calendarIcon.setImageDrawable(wrapDrawable);



        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        date_layout_button = (LinearLayout) findViewById(R.id.date_button_layout);
        dateLabel = (TextView) findViewById(R.id.date_label);
        currentLocale = getResources().getConfiguration().locale;
        dateFormatter = new SimpleDateFormat("dd MMM yyyy", currentLocale);
        setDateText(selectedDate);
        Calendar newCalendar = Calendar.getInstance();
        newCalendar.setTime(selectedDate);
        dateDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                selectedDate = newDate.getTime();
                setDateText(newDate.getTime());
                getTeeTimes();
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        dateDialog.setButton(AppCompatDialog.BUTTON_NEUTRAL, getString(R.string.Today), new AppCompatDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dateDialog.getDatePicker().setMinDate(new Date().getTime()  - 1000); //-1000 to prevent java.lang.IllegalArgumentException:

        dateDialog.setOnShowListener(new AppCompatDialog.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {

                Button b = dateDialog.getButton(AppCompatDialog.BUTTON_NEUTRAL);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar newCalendar = Calendar.getInstance();
                        dateDialog.getDatePicker().updateDate(newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

                    }
                });

            }
        });
        date_layout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dateDialog.show();
            }
        });



        discount_picker_button = (LinearLayout) findViewById(R.id.discount_layout_button);
        discount_picker_button_divider = (LinearLayout)findViewById(R.id.discount_layout_button_divider);
        discount_picker_button.setVisibility(View.GONE);
        discount_picker_button_divider.setVisibility(View.GONE);

        players_layout_button = (LinearLayout) findViewById(R.id.player_button_layout);
        players_label = (TextView) findViewById(R.id.player_number_label);
        final ArrayList<String> playerNumberStrings = new ArrayList<String>();
        playerNumberStrings.add(getString(R.string._1_player));
        playerNumberStrings.add("2 " + getString(R.string.lu_players));
        playerNumberStrings.add("3 " + getString(R.string.lu_players));
        playerNumberStrings.add("4 " + getString(R.string.lu_players));


        final NumberPicker playersNumberPicker = new NumberPicker(LGFFBookingActivity.this);
        players_label.setText(playerNumberStrings.get(0));
        playersNumberPicker.setMinValue(0);
        playersNumberPicker.setMaxValue(playerNumberStrings.size() - 1);
        playersNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);

        try {
            Field f = NumberPicker.class.getDeclaredField("mInputText");
            f.setAccessible(true);
            EditText inputText = null;
            inputText = (EditText) f.get(playersNumberPicker);
            inputText.setFilters(new InputFilter[0]);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        playersNumberPicker.setFormatter(new NumberPicker.Formatter() {

            @Override
            public String format(int value) {
                // TODO Auto-generated method stub
                return playerNumberStrings.get(value);
            }
        });
        final AlertDialog numberPlayerdialog = new AlertDialog.Builder(LGFFBookingActivity.this)
                .setTitle(R.string.Select)
                .setView(playersNumberPicker)
                .setPositiveButton(R.string.OK,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                players_label.setText(playerNumberStrings.get(playersNumberPicker.getValue()));
                                playersNumber = playersNumberPicker.getValue() + 1;
                                getTeeTimes();
                            }
                        })
                .setNegativeButton(R.string.Cancel,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                            }
                        }).create();

        players_layout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                numberPlayerdialog.show();
            }
        });



        getCourses();
        getDiscounts();


    }

    @Override
    protected void onResume() {
        super.onResume();
        if (teePublicIds.size() > 0)
            getTeeTimes();

    }

    private void getCourses() {
        teePublicIds = new ArrayList<String>();
        LGFFCourse.getCourses(this, mClubId, new LGFFSDKCallBack<Void, ArrayList<LGFFCourse>>() {
            @Override
            public Void onResponse(ArrayList<LGFFCourse> courses) {
                mCourses = courses;
                courseNames = new ArrayList<String>();
                for (LGFFCourse c : mCourses) {
                    for (LGFFTee t : c.tees) {
                        teePublicIds.add(t.publicId);
                        courseNames.add(c.name + " - " + t.name);
                    }
                    if (teePublicIds.size() > 0)
                        selectedTeePublicId = teePublicIds.get(0);

                }
                findTeeTimes();

                courseNumberPicker = new NumberPicker(LGFFBookingActivity.this);
                course_name_label = (TextView) findViewById(R.id.course_name_label);
                course_name_label.setText(courseNames.get(0));
                selectedTeeName = courseNames.get(0);
                courseNumberPicker.setMinValue(0);
                courseNumberPicker.setMaxValue(courseNames.size() - 1);
                courseNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);

                try {
                    Field f = NumberPicker.class.getDeclaredField("mInputText");
                    f.setAccessible(true);
                    EditText inputText = null;
                    inputText = (EditText) f.get(courseNumberPicker);
                    inputText.setFilters(new InputFilter[0]);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                }

                courseNumberPicker.setFormatter(new NumberPicker.Formatter() {

                    @Override
                    public String format(int value) {
                        // TODO Auto-generated method stub
                        return courseNames.get(value);
                    }
                });
                final AlertDialog courseDialog = new AlertDialog.Builder(LGFFBookingActivity.this)
                        .setTitle(R.string.Select)
                        .setView(courseNumberPicker)
                        .setPositiveButton(R.string.OK,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        course_name_label.setText(courseNames.get(courseNumberPicker.getValue()));
                                        selectedTeeName = courseNames.get(courseNumberPicker.getValue());
                                        if (teePublicIds.size() > 0)
                                            selectedTeePublicId = teePublicIds.get(courseNumberPicker.getValue());
                                        getTeeTimes();
                                    }
                                })
                        .setNegativeButton(R.string.Cancel,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                    }
                                }).create();


                course_picker_button = (LinearLayout) findViewById(R.id.course_picker_layout);
                course_picker_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        courseDialog.show();
                    }
                });
                return null;
            }

            @Override
            public void onError(LGFFError error) {
                loadingLayout.setVisibility(View.GONE);
                emptyLayout.setVisibility(View.VISIBLE);

                loadingLayout.setVisibility(View.GONE);
                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFBookingActivity.this);

                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }).setTitle(R.string.an_error_occurred);
                if (error != null) {
                    if (error.msg != null)
                        builder.setMessage(error.msg);
                }

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

    private void getDiscounts() {
        discountPublicIds = new ArrayList<String>();

        LGFFDiscount.getDiscounts(this, mClubId, new LGFFSDKCallBack<Void, ArrayList<LGFFDiscount>>() {
            @Override
            public Void onResponse(ArrayList<LGFFDiscount> discounts) {
                if(discounts.size() > 0){
                    discount_picker_button.setVisibility(View.VISIBLE);
                    discount_picker_button_divider.setVisibility(View.VISIBLE);
                }
                else{
                    discount_picker_button.setVisibility(View.GONE);
                    discount_picker_button_divider.setVisibility(View.GONE);
                }

                mDiscounts = discounts;
                final ArrayList<String> discountNames = new ArrayList<String>();
                discountNames.add(getString(R.string.discount_cards));
                discountPublicIds.add(getString(R.string.discount_cards));
                for (LGFFDiscount d : mDiscounts) {
                    discountNames.add(d.name + " - " + d.discount + "%");
                    discountPublicIds.add(d.discountID);
                }

                discount_label = (TextView) findViewById(R.id.discount_label);
                final NumberPicker discountNumberPicker = new NumberPicker(LGFFBookingActivity.this);
                discountNumberPicker.setMinValue(0);
                if (discountNames.size() > 0)
                    discountNumberPicker.setMaxValue(discountNames.size() - 1);
                discountNumberPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
                if (selectedDiscountId != null) {
                    for (int i = 0; i < discountPublicIds.size(); i++) {
                        if (discountPublicIds.get(i).equals(selectedDiscountId)) {
                            discountNumberPicker.setValue(i);
                            discount_label.setText(discountNames.get(i));
                        }
                    }

                }


                try {
                    Field f = NumberPicker.class.getDeclaredField("mInputText");
                    f.setAccessible(true);
                    EditText inputText = null;
                    inputText = (EditText) f.get(discountNumberPicker);
                    inputText.setFilters(new InputFilter[0]);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                }

                discountNumberPicker.setFormatter(new NumberPicker.Formatter() {

                    @Override
                    public String format(int value) {
                        // TODO Auto-generated method stub
                        return discountNames.get(value);
                    }
                });
                final AlertDialog discountDialog = new AlertDialog.Builder(LGFFBookingActivity.this)
                        .setTitle(R.string.Select)
                        .setView(discountNumberPicker)
                        .setPositiveButton(R.string.OK,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        if (discountNumberPicker.getValue() == 0) {
                                            discount_label.setText(R.string.discount_cards);
                                            selectedDiscountId = null;
                                        } else {
                                            discount_label.setText(discountNames.get(discountNumberPicker.getValue()));
                                            selectedDiscountId = discountPublicIds.get(discountNumberPicker.getValue());
                                        }
                                        getTeeTimes();
                                    }
                                })
                        .setNegativeButton(R.string.Cancel,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                    }
                                }).create();


                discount_picker_button.setOnClickListener(new View.OnClickListener()

                {
                    @Override
                    public void onClick(View v) {

                        discountDialog.show();
                    }
                });
                return null;
            }

            @Override
            public void onError(LGFFError error) {
                loadingLayout.setVisibility(View.GONE);
                emptyLayout.setVisibility(View.VISIBLE);
                loadingLayout.setVisibility(View.GONE);
                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFBookingActivity.this);

                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }).setTitle(R.string.an_error_occurred);
                if (error != null) {
                    if (error.msg != null)
                        builder.setMessage(error.msg);
                }

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }


    private void findTeeTimes() {
        if (teePublicIds.size() > courseIterator) {
            if (teePublicIds.get(courseIterator) != null) {

                loadingLayout.setVisibility(View.VISIBLE);
                SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd", currentLocale);
                LGFFTeeTime.getTeeTimes(this, mClubId, dateFormater.format(selectedDate.getTime()), null, teePublicIds.get(courseIterator), selectedDiscountId, new LGFFSDKCallBack<Void, ArrayList<LGFFTeeTime>>() {
                    @Override
                    public Void onResponse(final ArrayList<LGFFTeeTime> teeTimes) {
                        loadingLayout.setVisibility(View.GONE);
                        if (teeTimes.size() == 0) {
                            courseIterator++;
                            findTeeTimes();
                        } else {
                            emptyLayout.setVisibility(View.GONE);
                            mAdapter = new TeeTimesAdapter(teeTimes, getApplicationContext());
                            mAdapter.nbPlaces = playersNumber;
                            mAdapter.setOnItemClickListener(new TeeTimesAdapter.ClickListener() {
                                @Override
                                public void onItemClick(int position, View v) {
                                    selectedTeeTime = teeTimes.get(position);
                                    selectedTeeName = courseNames.get(courseIterator);
                                    reloadUserInfo();
                                }
                            });
                            mRecyclerView.setAdapter(mAdapter);
                            selectedTeePublicId = teePublicIds.get(courseIterator);
                            course_name_label.setText(courseNames.get(courseIterator));
                            courseNumberPicker.setValue(courseIterator);
                        }
                        return null;
                    }

                    @Override
                    public void onError(LGFFError error) {
                        loadingLayout.setVisibility(View.GONE);
                        emptyLayout.setVisibility(View.VISIBLE);
                        loadingLayout.setVisibility(View.GONE);
                        AlertDialog.Builder builder = new AlertDialog.Builder(LGFFBookingActivity.this);

                        builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        }).setTitle(R.string.an_error_occurred);
                        if (error != null) {
                            if(error.msg != null)
                                builder.setMessage(error.msg);
                        }

                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }

                });
            }
        } else
            getTeeTimes();
    }

    private void getTeeTimes() {
        loadingLayout.setVisibility(View.VISIBLE);
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd", currentLocale);
        LGFFTeeTime.getTeeTimes(this, mClubId, dateFormater.format(selectedDate.getTime()), null, selectedTeePublicId, selectedDiscountId, new LGFFSDKCallBack<Void, ArrayList<LGFFTeeTime>>() {
            @Override
            public Void onResponse(final ArrayList<LGFFTeeTime> teeTimes) {
                loadingLayout.setVisibility(View.GONE);
                if (teeTimes.size() == 0)
                    emptyLayout.setVisibility(View.VISIBLE);
                else
                    emptyLayout.setVisibility(View.GONE);
                mAdapter = new TeeTimesAdapter(teeTimes, getApplicationContext());
                mAdapter.nbPlaces = playersNumber;
                mAdapter.setOnItemClickListener(new TeeTimesAdapter.ClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        selectedTeeTime = teeTimes.get(position);
                        reloadUserInfo();
                    }
                });
                mRecyclerView.setAdapter(mAdapter);
                return null;
            }

            @Override
            public void onError(LGFFError error) {
                loadingLayout.setVisibility(View.GONE);
                emptyLayout.setVisibility(View.VISIBLE);
                loadingLayout.setVisibility(View.GONE);
                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFBookingActivity.this);

                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }).setTitle(R.string.an_error_occurred);
                if (error != null) {
                    if(error.msg != null)
                        builder.setMessage(error.msg);
                }

                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });
    }

    private void setDateText(Date date) {
        Calendar c = Calendar.getInstance();
        Date today = c.getTime();
        c.add(Calendar.DATE, 1);
        Date tomorow = c.getTime();
        if (dateFormatter.format(date.getTime()).equals(dateFormatter.format(today.getTime())))
            dateLabel.setText(dateFormatter.format(date.getTime()) + " - " + getString(R.string.Today));
        else if (dateFormatter.format(date.getTime()).equals(dateFormatter.format(tomorow.getTime())))
            dateLabel.setText(dateFormatter.format(date.getTime()) + " - " + getString(R.string.Tomorrow));
        else
            dateLabel.setText(dateFormatter.format(date.getTime()));
    }


    public void reloadUserInfo(){
        if(MyGreenFeeKit.getDelegate().getUserInfo() != null){
            int errorKind = 0;
            LGFFUserInfo user = MyGreenFeeKit.getDelegate().getUserInfo();

            if(user.getLastName() != null){
                if(user.getLastName().equals(""))
                    errorKind = errorKind | LGFFError.missingLastName;
            }else
                errorKind = errorKind | LGFFError.missingLastName;

            if(user.getFirstName() != null){
                if(user.getFirstName().equals(""))
                    errorKind = errorKind | LGFFError.missingFirstName;
            }else
                errorKind = errorKind | LGFFError.missingFirstName;

            if(user.getBirthDate() != null){
                if(user.getBirthDate().equals(""))
                    errorKind = errorKind | LGFFError.missingBirthday;
            }else
                errorKind = errorKind | LGFFError.missingBirthday;

            if(user.getEmail() != null){
                if(user.getEmail().equals(""))
                    errorKind = errorKind | LGFFError.missingEmail;
                else if(!isValidEmail(user.getEmail()))
                    errorKind = errorKind | LGFFError.invalideEmail;
            }else
                errorKind = errorKind | LGFFError.missingEmail;

            if(errorKind == 0){
                LGFFUserInfo userInfo = MyGreenFeeKit.getDelegate().getUserInfo();
                createOrder(userInfo);
            } else{
                LGFFError error = new LGFFError(null, errorKind);
                MyGreenFeeKit.getDelegate().onBookingFailled(this, error, new Runnable() {
                    @Override
                    public void run() {
                        //Log.d("reloadUserInfo", "reloadUserInfo");
                        reloadUserInfo();
                    }
                });
            }

        }
        else{
            LGFFError error = new LGFFError(null, LGFFError.missingLastName  | LGFFError.missingFirstName | LGFFError.missingBirthday  | LGFFError.missingEmail);
            MyGreenFeeKit.getDelegate().onBookingFailled(this, error, new Runnable() {
                @Override
                public void run() {
                    //Log.d("reloadUserInfo", "reloadUserInfo");
                    reloadUserInfo();
                }
            });
        }

    }

    public final static boolean isValidEmail(CharSequence target) {
        if (TextUtils.isEmpty(target)) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    private void createOrder(final LGFFUserInfo userInfo){


        loadingOverlay.setVisibility(View.VISIBLE);
       final LGFFOrder order = new LGFFOrder(selectedTeeTime.date, selectedTeeTime.time, playersNumber, selectedDiscountId, mClubId, mClubName, selectedTeePublicId, selectedTeeName, userInfo);
       LGFFOrder.postOrder(this, order, userInfo, new LGFFSDKCallBack<Void, String>() {
           @Override
           public Void onResponse(String param) {
               loadingOverlay.setVisibility(View.GONE);
               LGFFOrder freshNewOrder = new LGFFOrder(param);
               if(freshNewOrder != null){
               freshNewOrder.clubId = order.clubId;
               freshNewOrder.time = order.time;
               freshNewOrder.clubName = order.clubName;
               freshNewOrder.placeNumber = order.placeNumber;
               freshNewOrder.date = order.date;
               freshNewOrder.discountId = order.discountId;
               freshNewOrder.teeID = order.teeID;
               freshNewOrder.teeName = order.teeName;
               freshNewOrder.userInfo = userInfo;
               }
               MyGreenFeeKit.getDelegate().onUserInfoAccepted();

               proceedPayment(freshNewOrder);
               return null;
           }


           @Override
           public void onError(LGFFError error) {
               MyGreenFeeKit.getDelegate().onUserInfoAccepted();
               loadingLayout.setVisibility(View.GONE);
               loadingOverlay.setVisibility(View.GONE);
               AlertDialog.Builder builder = new AlertDialog.Builder(LGFFBookingActivity.this);

               builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {

                   }
               }).setTitle(R.string.an_error_occurred);
               if (error != null) {
                   if(error.msg != null)
                       builder.setMessage(error.msg);
               }

               AlertDialog dialog = builder.create();
               dialog.show();
               MyGreenFeeKit.getDelegate().onBookingFailled(LGFFBookingActivity.this, error, null);
           }
       });


    }

    private void proceedPayment(LGFFOrder order) {
        MyGreenFeeKit.setCurrentOrder(order);
        Intent intent = new Intent(LGFFBookingActivity.this, LGFFPaymentActivity.class);
        Bundle b = new Bundle();
        b.putDouble("price", selectedTeeTime.salePrice * order.placeNumber);
        intent.putExtras(b);
        startActivityForResult(intent, MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        if (id  == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE) {
            if(resultCode == Activity.RESULT_OK){
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
        }
    }
}
