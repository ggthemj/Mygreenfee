package com.legreenfee.legreenfeesdk;

/**
 * Created by user on 22/02/2016.
 */
public class LGFFError {


    public int kind;
    public String msg;

    public final static int missingLastName = 1;           		// 000000001 in binary
    public final static int missingFirstName = (1 << 1);         		// 000000010 in binary
    public final static int missingBirthday = (1 << 2);         		// 000000100 in binary
    public final static int missingEmail = (1 << 3);    		// 000001000 in binary
    public final static int invalideEmail = (1 << 4);	 	  		// 000010000 in binary
    public final static int networkError = (1 << 5);
    public final static int checkPaymentUrlneeded = (1 << 6);


    public LGFFError(String msg, int kind) {
        this.msg = msg;
        this.kind = kind;
    }
}
