package com.legreenfee.legreenfeesdk;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by user on 10/02/2016.
 */
public class LGFFTeeTime {
    String teeTimeId = "";
    String date;
    String time = "";
    Double salePrice;
    Double totalPrice;
    Integer reduction;
    Integer slotsFree;
    Integer slotsMax;
    Integer bonChoix;
    Integer special;


    public LGFFTeeTime(JSONObject json) {

        try {
            if(!json.isNull("public_id"))
                this.teeTimeId = json.getString("public_id");
            if(!json.isNull("date"))
                this.date = json.getString("date");
            if(!json.isNull("time"))
                this.time = json.getString("time");
            if(!json.isNull("sale_price"))
                this.salePrice = json.getDouble("sale_price");
            if(!json.isNull("total_price"))
                this.totalPrice = json.getDouble("total_price");
            if(!json.isNull("reduction"))
                this.reduction = json.getInt("reduction");
            if(!json.isNull("slots_free"))
                this.slotsFree = json.getInt("slots_free");
            if(!json.isNull("slots_max"))
                this.slotsMax = json.getInt("slots_max");
            if(!json.isNull("bon_choix"))
                this.bonChoix = json.getInt("bon_choix");
            if(!json.isNull("special"))
                this.special = json.getInt("special");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /* package */ static ArrayList<LGFFTeeTime> parseJson(JSONObject json) {
        ArrayList<LGFFTeeTime> teeTimes = new  ArrayList<LGFFTeeTime>();
        JSONArray jsonTeeTimes;
        try {
            if(json.has("teetimes")){
                jsonTeeTimes = json.getJSONArray("teetimes");
                for (int i = 0; i < jsonTeeTimes.length(); i++) {

                    teeTimes.add(new LGFFTeeTime(jsonTeeTimes.getJSONObject(i)));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return teeTimes;
    }







    /* package */ static void getTeeTimes(Context context, String clubId, String date, String time, String teePublicId, String discountId, LGFFSDKCallBack <Void, ArrayList<LGFFTeeTime>>callBack){
        MyGreenFeeKit.getNetworkManager().getTeeTimes(context, clubId, date, teePublicId, discountId, callBack);
    }
}
