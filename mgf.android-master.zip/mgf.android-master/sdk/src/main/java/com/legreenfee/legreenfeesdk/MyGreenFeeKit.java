package com.legreenfee.legreenfeesdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;

import org.json.JSONObject;

import java.util.Date;
import java.util.Locale;

public class MyGreenFeeKit {

    public final static boolean isDev = false;
    public final static boolean check3DSecure = false; // sandbox check3Dsecure for testing, only if isDev is set to true
    final static String CHECK_PAYMENT_RETURN_URL = "http://legreenfee.com/app/android/checkpayementurl/";
    public final static int BOOKING_SUCCES_ACTIVITY_RESULT_CODE = 4242;

    private static MyGreenFeeKit instance = null;



    private static Locale locale;
    private static LGFFBookingDelegate delegate;
    private static NetworkManager networkManager;

    private static String apiKey = "";



    private static LGFFOrder currentOrder;

    private MyGreenFeeKit() {       }

    /**
     * Initialize MyGreenFee.
     */
    public static MyGreenFeeKit init(Context context, String apiKey) {
        if (instance == null) {
            instance = new MyGreenFeeKit ();
        }
        if(isDev)
            MyGreenFeeKit.apiKey = context.getString(R.string.x_dev_api_key);
        else
            MyGreenFeeKit.apiKey = apiKey;
        MyGreenFeeKit.networkManager = new NetworkManager(context);
        MyGreenFeeKit.locale = context.getResources().getConfiguration().locale;
        return instance;
    }



    /* package */ static String getApiKey() {
        return apiKey;
    }


    /* package*/ static NetworkManager getNetworkManager() {
        return networkManager;
    }

    /* package */ static void setDelegate(LGFFBookingDelegate delegate) {
        MyGreenFeeKit.delegate = delegate;
    }

    /* package */ static LGFFBookingDelegate getDelegate() {
        return delegate;
    }


    /**
     * Start the booking process.
     *
     * It is your responsability, at this time, to invoke reloadUserInfo, so that the booking process
     * can continue.
     *
     * After reloadUserInfo has been invoked, this method will be called again.
     *
     * Eventually, onUserInfoAccepted or onBookingFailled will be called.
     *
     *
     * For example, your application may present a form in a modal Activity, and
     * call reloadUserInfo when the user submits the form. Keep the form on screen until
     * onUserInfoAccepted:. Then simply dismiss your form Activity.
     *
     * On onBookingFailled, present the error to the user, and let him correct his input.
     *
     * @param activity
     * @param club
     * @param delegate
     */
    public static void startBookingActivity(Activity activity, @NonNull LGFFClub club, @NonNull LGFFBookingDelegate delegate) {
        MyGreenFeeKit.setDelegate(delegate);
        Intent intent = new Intent(activity, LGFFBookingActivity.class );
        Bundle b = new Bundle();
        b.putString("club_id", club.clubID);
        b.putString("club_name", club.name);
        intent.putExtras(b);
        activity.startActivityForResult( intent, BOOKING_SUCCES_ACTIVITY_RESULT_CODE);
    }

    /* package */ static LGFFOrder getCurrentOrder() {
        return currentOrder;
    }

    /* package */ static void setCurrentOrder(LGFFOrder currentOrder) {
        MyGreenFeeKit.currentOrder = currentOrder;
    }

    /* package */ static Locale getLocale() {
        return locale;
    }

    static String getClubsUrl(Context context) {
       return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.clubs_url);
    }

    static String getCoursesUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.courses_url);
    }

    static String getDicountsUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.discounts_url);
    }

    static String getTeeTimesUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.tee_times_url);
    }

    static String getOrdersUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.orders_url);
    }

    static String getCheckCardUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.check_card);
    }

    static String getCreateCardUrl(Context context) {
        return MyGreenFeeKit.getApiBaseUrl(context) + context.getString(R.string.create_card);
    }

    private static String getApiBaseUrl(Context context){
        if(isDev)
            return context.getString(R.string.api_dev_base_url);
        else
            return context.getString(R.string.api_base_url);
    }

    /* package */ static void checkCard(Context context, String email, String currency,  LGFFSDKCallBack <Void, JSONObject>callBack){
        MyGreenFeeKit.networkManager.checkCard(context, email, currency, callBack);
    }

    /* package */ static void createCard(Context context, String email, String cardNumber, Date cardDate, String securityCode,  LGFFSDKCallBack <Void, String>callBack){
        MyGreenFeeKit.networkManager.createCard(context, email, cardNumber, cardDate, securityCode, callBack);
    }

    /* package */ static void cardPayOrder(Context context, LGFFOrder order, LGFFUserInfo user, final String securityCode,LGFFSDKCallBack <Void, String>callBack){
        MyGreenFeeKit.networkManager.cardPayOrder(context, order, user, securityCode, callBack);
    }

    /* package */ static void confirmOrder(Context context, LGFFOrder order, LGFFUserInfo user,LGFFSDKCallBack <Void, String>callBack){
        MyGreenFeeKit.networkManager.confirmOrder(context, order, user, callBack);
    }
}


