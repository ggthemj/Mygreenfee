package com.legreenfee.legreenfeesdk;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class PaymentUrlActivity extends AppCompatActivity {

    private WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_url);

        String url;
        Bundle b = getIntent().getExtras();
        url =  b.getString("url");



        webView = (WebView) findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {


            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Here put your code

                if (url.equals(MyGreenFeeKit.CHECK_PAYMENT_RETURN_URL)) {
                    Intent returnIntent = new Intent();
                    setResult(Activity.RESULT_OK,returnIntent);
                    finish();
                }

                // return true; //Indicates WebView to NOT load the url;
                return false; //Allow WebView to load url
            }
        });


        if(MyGreenFeeKit.isDev && MyGreenFeeKit.check3DSecure){
            String customHtml = "<html><body><h1><A href=\"http://legreenfee.com/app/android/checkpayementurl/\">confirm payment</A></h1><h1><A href=\"http://www.google.com\">www.google.com</A></h1></body></html>";
            webView.loadData(customHtml, "text/html", "UTF-8");
        }
        else
            webView.loadUrl(url);

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }

        }
        return super.onKeyDown(keyCode, event);
    }
}
