package com.legreenfee.legreenfeesdk;



import java.util.ArrayList;

/**
 * Created by user on 04/02/2016.
 */

public interface LGFFSDKCallBack<ReturnType, ParamType> {

    ReturnType onResponse(ParamType param);
    void onError(LGFFError error);
}



