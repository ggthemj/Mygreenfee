package com.legreenfee.legreenfeesdk;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LGFFDiscount {
    public String discountID = "";
    public String name = "";
    public Integer discount;

    public LGFFDiscount(JSONObject json) {

        try {
            if(!json.isNull("public_id"))
                this.discountID = json.getString("public_id");
            if(!json.isNull("name"))
                this.name = json.getString("name");
            if(!json.isNull("discount"))
                this.discount = json.getInt("discount");
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /* package */ static ArrayList<LGFFDiscount> parseJson(JSONObject json) {
        ArrayList<LGFFDiscount> discounts = new  ArrayList<LGFFDiscount>();
        JSONArray jsonDiscounts;
        try {
            if(json.has("discounts")){
                jsonDiscounts = json.getJSONArray("discounts");
                for (int i = 0; i < jsonDiscounts.length(); i++) {

                    discounts.add(new LGFFDiscount(jsonDiscounts.getJSONObject(i)));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return discounts;
    }

    /* package */ static void getDiscounts(Context context, String clubId, LGFFSDKCallBack <Void, ArrayList<LGFFDiscount>>callBack){
        MyGreenFeeKit.getNetworkManager().getDiscounts(context, clubId, callBack);
    }
}
