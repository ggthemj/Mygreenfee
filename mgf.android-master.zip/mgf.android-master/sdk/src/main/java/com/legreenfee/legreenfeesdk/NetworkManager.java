package com.legreenfee.legreenfeesdk;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.legreenfee.volley.AuthFailureError;
import com.legreenfee.volley.DefaultRetryPolicy;
import com.legreenfee.volley.NoConnectionError;
import com.legreenfee.volley.Request;
import com.legreenfee.volley.RequestQueue;
import com.legreenfee.volley.Response;
import com.legreenfee.volley.VolleyError;
import com.legreenfee.volley.VolleyLog;
import com.legreenfee.volley.toolbox.JsonObjectRequest;
import com.legreenfee.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class NetworkManager {
    public static final String TAG = NetworkManager.class.getSimpleName();
    private final static String GET_TEE_TIMES_TAG = "42";
    private RequestQueue mRequestQueue;
    private String networkError;
    private String captiveNetworkError;

    /* package */ NetworkManager(Context context) {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(context);
        }
        networkError = context.getString(R.string.please_check_your_internet_connection_and_try_again_later);
        captiveNetworkError = context.getString(R.string.you_may_be_connecting_through_a_captive_network_please_check_your_internet_connection_and_try_again_);
    }

    /* package */ RequestQueue getRequestQueue() {

        return mRequestQueue;
    }

    /* package */ <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

    /* package */ <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        getRequestQueue().add(req);
    }

    /* package */ void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }


    /* package */ void getClubs(Context context, LGFFSDKCallBack<Void, ArrayList<LGFFClub>> callBack) {
        final LGFFSDKCallBack<Void, ArrayList<LGFFClub>> cb = callBack;


        JsonObjectRequest jsonObjReq = new CustomJsonObjectRequest(Request.Method.GET,
                MyGreenFeeKit.getClubsUrl(context), null, new Response.Listener<JSONObject>() {


            @Override
            public void onResponse(JSONObject r) {
                ArrayList<LGFFClub> clubs = LGFFClub.parseJson(r);
                cb.onResponse(clubs);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null)
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));
            }
        });
        addToRequestQueue(jsonObjReq);
    }


    /* package */ void getCourses(Context context, String clubId, LGFFSDKCallBack<Void, ArrayList<LGFFCourse>> callBack) {
        final LGFFSDKCallBack<Void, ArrayList<LGFFCourse>> cb = callBack;


        String url = MyGreenFeeKit.getCoursesUrl(context) + "&data[club_id]=" + clubId;
        JsonObjectRequest jsonObjReq = new CustomJsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {


            @Override
            public void onResponse(JSONObject r) {
                ArrayList<LGFFCourse> courses = LGFFCourse.parseJson(r);
                cb.onResponse(courses);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null)
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));


            }
        });
        addToRequestQueue(jsonObjReq);
    }


    /* package */ void getDiscounts(Context context, String clubId, LGFFSDKCallBack<Void, ArrayList<LGFFDiscount>> callBack) {
        final LGFFSDKCallBack<Void, ArrayList<LGFFDiscount>> cb = callBack;


        String url = MyGreenFeeKit.getDicountsUrl(context) + "&data[club_id]=" + clubId;
        JsonObjectRequest jsonObjReq = new CustomJsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {


            @Override
            public void onResponse(JSONObject r) {
                ArrayList<LGFFDiscount> discounts = LGFFDiscount.parseJson(r);
                cb.onResponse(discounts);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null)
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));
            }
        });
        addToRequestQueue(jsonObjReq);
    }

    /* package */ void getTeeTimes(Context context, String clubId, String date, String teeId, String discountId, LGFFSDKCallBack<Void, ArrayList<LGFFTeeTime>> callBack) {
        final LGFFSDKCallBack<Void, ArrayList<LGFFTeeTime>> cb = callBack;


        String url = MyGreenFeeKit.getTeeTimesUrl(context) + "&data[club_id]=" + clubId;
        if (date != null && !date.equals(""))
            url += "&data[date]=" + date;
        if (teeId != null && !teeId.equals(""))
            url += "&data[tee_id]=" + teeId;
        if (discountId != null && !discountId.equals(""))
            url += "&data[discount_id]=" + discountId;
        JsonObjectRequest jsonObjReq = new CustomJsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {


            @Override
            public void onResponse(JSONObject r) {
                ArrayList<LGFFTeeTime> teeTimes = LGFFTeeTime.parseJson(r);
                cb.onResponse(teeTimes);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());


                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null)
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        });
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }

    /* package */ void postOrder(Context context, LGFFOrder order, final LGFFUserInfo user, LGFFSDKCallBack<Void, String> callBack) {
        final LGFFSDKCallBack<Void, String> cb = callBack;
        final LGFFOrder o = order;
        final LGFFUserInfo u = user;


        String url = MyGreenFeeKit.getOrdersUrl(context);
        CustomStringRequest jsonObjReq = new CustomStringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {


            @Override
            public void onResponse(String r) {
                Log.d("orders_request", "order : " + r);
                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                if (o.clubId != null && !o.clubId.equals(""))
                    params.put("data[club_id]", o.clubId);
                if (o.teeID != null && !o.clubId.equals(""))
                    params.put("data[tee_id]", o.teeID);
                if (o.date != null && !o.date.equals(""))
                    params.put("data[date]", o.date);
                if (o.time != null && !o.time.equals(""))
                    params.put("data[time]", o.time);
                if (o.placeNumber != null && !o.placeNumber.toString().equals(""))
                    params.put("data[nb_places]", o.placeNumber.toString());

                if (u.email != null && !u.email.equals(""))
                    params.put("data[email]", u.email);

                if (u.firstName != null && !u.firstName.equals(""))
                    params.put("data[first_name]", u.firstName);

                if (u.lastName != null && !u.lastName.equals(""))
                    params.put("data[last_name]", u.lastName);
                ;

                if (u.phone != null && !u.phone.equals(""))
                    params.put("data[phone]", u.phone);
                params.put("data[gender]", "male");

                if (o.discountId != null && !o.discountId.equals(""))
                    params.put("data[discount_id]", o.discountId);
                return params;
            }

            @Override
            public String getBodyContentType() {
                // TODO Auto-generated method stub
                return "application/x-www-form-urlencoded";
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }


    /* package */ void cancelOrder(Context context, LGFFOrder order, LGFFSDKCallBack<Void, String> callBack) {
        final LGFFSDKCallBack<Void, String> cb = callBack;


        String url = MyGreenFeeKit.getOrdersUrl(context);
        url += "/" + order.orderID;
        url += "/cancel";

        CustomStringRequest jsonObjReq = new CustomStringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {


            @Override
            public void onResponse(String r) {
                //Log.d("orders_request", "order : " + r);
                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {
                  //  Log.d("cancelOrder", "error : " + getErrorMessage(new String(error.networkResponse.data)));
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                return params;
            }

            @Override
            public String getBodyContentType() {
                // TODO Auto-generated method stub
                return "application/x-www-form-urlencoded";
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }


    /* package */ void checkCard(Context context, String email, String currencyCode, LGFFSDKCallBack<Void, JSONObject> callBack) {
        final LGFFSDKCallBack<Void, JSONObject> cb = callBack;


        String url = MyGreenFeeKit.getCheckCardUrl(context);
        url += "&data[email]=";
        url += email;
        if (currencyCode != null)
            url += "&data[currency]=" + currencyCode;
        else
            url += "&data[currency]=" + "eur";

        JsonObjectRequest jsonObjReq = new CustomJsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {


            @Override
            public void onResponse(JSONObject r) {

                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                    //Log.d("checkCardError", "Error: " + getErrorMessage(new String(error.networkResponse.data)));
                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));


            }
        });
        addToRequestQueue(jsonObjReq);
    }


    /* package */ void createCard(Context context, final String email, final String cardNumber, final Date cardDate, final String securityCode, LGFFSDKCallBack<Void, String> callBack) {
        final LGFFSDKCallBack<Void, String> cb = callBack;


        String url = MyGreenFeeKit.getCreateCardUrl(context);
        CustomStringRequest jsonObjReq = new CustomStringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {


            @Override
            public void onResponse(String r) {
              //  Log.d("create_card_request", "response : " + r);
                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {
                //    Log.d("create_card_request", "error : " + getErrorMessage(new String(error.networkResponse.data)));
                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));
                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                if (email != null && !email.equals(""))
                    params.put("data[email]", email);
                if (cardDate != null) {
                    SimpleDateFormat dateFormater = new SimpleDateFormat("MMyy", Locale.getDefault());
                    params.put("data[expiration_date]", dateFormater.format(cardDate)); // a formatter
                }
                if (cardNumber != null && !cardNumber.equals(""))
                    params.put("data[card_number]", cardNumber);
                if (securityCode != null && !securityCode.equals(""))
                    params.put("data[card_cvx]", securityCode);

                return params;
            }

            @Override
            public String getBodyContentType() {
                // TODO Auto-generated method stub
                return "application/x-www-form-urlencoded";
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }


    /* package */ void cardPayOrder(Context context, LGFFOrder order, LGFFUserInfo user, final String securityCode, LGFFSDKCallBack<Void, String> callBack) {
        final LGFFSDKCallBack<Void, String> cb = callBack;

        final LGFFUserInfo u = user;

        String url = MyGreenFeeKit.getOrdersUrl(context);
        url += "/" + order.orderID;
        url += "/card";

        CustomStringRequest jsonObjReq = new CustomStringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {


            @Override
            public void onResponse(String r) {
                //Log.d("orders_request", "order : " + r);
                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                if (MyGreenFeeKit.isDev && MyGreenFeeKit.check3DSecure) {

                    LGFFError e = new LGFFError("http://www.google.com", LGFFError.checkPaymentUrlneeded);
                    cb.onError(e);
                    return;

                }

                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {
                    String paymentUrl;
                    paymentUrl = get3DSecureUrl(new String(error.networkResponse.data));
                    if (paymentUrl != null)
                        cb.onError(new LGFFError(paymentUrl, LGFFError.checkPaymentUrlneeded));
                    else
                        cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));


                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                if (u.email != null && !u.email.equals(""))
                    params.put("data[email]", u.email);

                if (securityCode != null && !securityCode.equals(""))
                    params.put("data[csc]", securityCode);

                params.put("data[return_url]", MyGreenFeeKit.CHECK_PAYMENT_RETURN_URL);


                return params;
            }

            @Override
            public String getBodyContentType() {
                // TODO Auto-generated method stub
                return "application/x-www-form-urlencoded";
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }


    /* package */ void confirmOrder(Context context, LGFFOrder order, LGFFUserInfo user, LGFFSDKCallBack<Void, String> callBack) {
        final LGFFSDKCallBack<Void, String> cb = callBack;

        final LGFFUserInfo u = user;

        String url = MyGreenFeeKit.getOrdersUrl(context);
        url += "/" + order.orderID;
        url += "/confirm";

        CustomStringRequest jsonObjReq = new CustomStringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {


            @Override
            public void onResponse(String r) {
                //Log.d("orders_request", "order : " + r);
                cb.onResponse(r);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                if (error.getClass().equals(NoConnectionError.class)) {
                    cb.onError(new LGFFError(networkError, LGFFError.networkError));
                } else if (error.networkResponse != null && error.networkResponse.data != null) {

                    cb.onError(new LGFFError(getErrorMessage(new String(error.networkResponse.data)), LGFFError.networkError));


                } else
                    cb.onError(new LGFFError(captiveNetworkError, LGFFError.networkError));

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                if (u.email != null && !u.email.equals(""))
                    params.put("data[email]", u.email);

                return params;
            }

            @Override
            public String getBodyContentType() {
                // TODO Auto-generated method stub
                return "application/x-www-form-urlencoded";
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cancelPendingRequests(GET_TEE_TIMES_TAG);
        addToRequestQueue(jsonObjReq, GET_TEE_TIMES_TAG);
    }

    private String get3DSecureUrl(String error) {
        String result = null;
        JSONObject json;
        try {
            json = new JSONObject(error);
            if (json.has("payment_url"))
                result = json.getString("payment_url");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    private String getErrorMessage(String error) {
        JSONObject json;
        String errorMessage = "";
        try {
            json = new JSONObject(error);
            if (json.has("error_message"))
                errorMessage = json.getString("error_message");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return errorMessage;
    }

}
