package com.legreenfee.legreenfeesdk;

import com.legreenfee.volley.AuthFailureError;
import com.legreenfee.volley.Response;
import com.legreenfee.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CustomJsonObjectRequest extends JsonObjectRequest
{
    public CustomJsonObjectRequest(int method, String url, JSONObject jsonRequest,Response.Listener listener, Response.ErrorListener errorListener)
    {
        super(method, url, jsonRequest, listener, errorListener);
    }

    @Override
    public Map getHeaders() throws AuthFailureError {
        final Map<String, String> mHeaders = new HashMap<String, String>();
        mHeaders.put("X-API-KEY", MyGreenFeeKit.getApiKey());
        mHeaders.put("CONTENT-LANGUAGE", Locale.getDefault().getLanguage().toUpperCase());
        return mHeaders;
    }

}