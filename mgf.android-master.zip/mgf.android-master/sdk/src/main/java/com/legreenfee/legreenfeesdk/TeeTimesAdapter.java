package com.legreenfee.legreenfeesdk;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by user on 10/02/2016.
 */
public class TeeTimesAdapter extends RecyclerView.Adapter<TeeTimesAdapter.ViewHolder> {
    private static ClickListener clickListener;
    private ArrayList<LGFFTeeTime> mDataset = new ArrayList<LGFFTeeTime>();
    private Context mContext;
    public int nbPlaces = 1;
    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener {
        // each data item is just a string in this case
        public TextView freeSlots;
        public TextView time;
        public TextView price;
        public ImageView discountIcon;
        public TextView book;
        public ViewHolder(View v) {
            super(v);
            freeSlots = (TextView)v.findViewById(R.id.free_slots);
            time = (TextView)v.findViewById(R.id.time);
            price = (TextView)v.findViewById(R.id.price);
            book = (TextView)v.findViewById(R.id.book_tee_time);
            discountIcon = (ImageView)v.findViewById(R.id.discount_icon);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public TeeTimesAdapter(ArrayList<LGFFTeeTime> teeTimes, Context context) {
        mDataset = teeTimes;
        mContext = context;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public TeeTimesAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                   int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.tee_times_row, parent, false);
        // set the view's size, margins, paddings and layout parameters

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.freeSlots.setText(mDataset.get(position).slotsFree.toString() + " " + mContext.getString(R.string.i_dispo));
        holder.time.setText(mDataset.get(position).time.toString());
        holder.price.setText( String.format("%.2f €", mDataset.get(position).salePrice));

        if(mDataset.get(position).slotsFree < nbPlaces){
            holder.itemView.setEnabled(false);
            holder.book.setTextColor(mContext.getResources().getColor(R.color.grey_disabled));
        }else{
            holder.itemView.setEnabled(true);
            holder.book.setTextColor(mContext.getResources().getColor(R.color.colorAccent));
        }

        if(mDataset.get(position).reduction > 0) {
            holder.discountIcon.setVisibility(View.VISIBLE);
            if(mDataset.get(position).bonChoix == 1)
                holder.discountIcon.setImageBitmap(RotateBitmap(drawTextToBitmap(mContext, R.drawable.discount_red, "-" + mDataset.get(position).reduction + "%", Color.rgb(255, 255, 255), true), -20));
            else
                holder.discountIcon.setImageBitmap(RotateBitmap(drawTextToBitmap(mContext, R.drawable.discount_white, "-" + mDataset.get(position).reduction + "%", Color.rgb(0, 0, 0), false), -20));
        }else
            holder.discountIcon.setVisibility(View.GONE);

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }
    public void setOnItemClickListener(ClickListener clickListener) {
        TeeTimesAdapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }


    public Bitmap drawTextToBitmap(Context gContext,
                                   int gResId,
                                   String gText, int textColor, boolean shadow) {
        Resources resources = gContext.getResources();
        float scale = resources.getDisplayMetrics().density;
        Bitmap bitmap =
                BitmapFactory.decodeResource(resources, gResId);

        android.graphics.Bitmap.Config bitmapConfig =
                bitmap.getConfig();
        // set default bitmap config if none
        if(bitmapConfig == null) {
            bitmapConfig = android.graphics.Bitmap.Config.ARGB_8888;
        }
        // resource bitmaps are imutable,
        // so we need to convert it to mutable one
        bitmap = bitmap.copy(bitmapConfig, true);

        Canvas canvas = new Canvas(bitmap);
        // new antialised Paint
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        paint.setColor(textColor);
        // text size in pixels
        paint.setTextSize((int) (15 * scale));
        // text shadow
        if(shadow)
            paint.setShadowLayer(1f, 0f, 1f, Color.BLACK);

        // draw text to the Canvas center
        Rect bounds = new Rect();
        paint.getTextBounds(gText, 0, gText.length(), bounds);
        int x = (bitmap.getWidth() - bounds.width())/2 + ((bitmap.getWidth() - bounds.width())/6);
        int y = (bitmap.getHeight() + bounds.height())/2;

        canvas.drawText(gText, x, y, paint);

        return bitmap;
    }


    public static Bitmap RotateBitmap(Bitmap source, float angle)
    {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }
}