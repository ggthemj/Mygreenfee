package com.legreenfee.legreenfeesdk;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LGFFClub {

    public String clubID = "";
    public String name = "";
    public String detailedDescription = "";
    public String address = "";
    public String email = "";
    public String url = "";
    public double lat = 0;
    public double lng = 0;
    //TimeZone* timezone;
    //String searchableString;
    String currencyCode = "";


    public LGFFClub(JSONObject json) {

        try {
            if(!json.isNull("public_id"))
                this.clubID = json.getString("public_id");
            if(!json.isNull("name"))
                this.name = json.getString("name");
            if(!json.isNull("description"))
                this.detailedDescription = json.getString("description");
            if(!json.isNull("address"))
                this.address = json.getString("address");
            if(!json.isNull("email"))
                this.email = json.getString("email");
            if(!json.isNull("url"))
                this.url = json.getString("url");
            if(!json.isNull("latitude"))
                this.lat = json.getDouble("latitude");
            if(!json.isNull("longitude"))
                this.lng = json.getDouble("longitude");

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    /* package */ static ArrayList<LGFFClub> parseJson(JSONObject json) {
        ArrayList<LGFFClub> clubs = new  ArrayList<LGFFClub>();
        JSONArray jsonClubs;
        try {
            if(json.has("clubs")){
                jsonClubs = json.getJSONArray("clubs");
                for (int i = 0; i < jsonClubs.length(); i++) {

                    clubs.add(new LGFFClub(jsonClubs.getJSONObject(i)));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return clubs;
    }


    /**
     *
     * Asynchronous call retrieving clubs
     *
     * @param context
     * @param callBack
     */
    public static void getClubs(Context context, LGFFSDKCallBack <Void, ArrayList<LGFFClub>>callBack){
       MyGreenFeeKit.getNetworkManager().getClubs(context, callBack);
    }


}
