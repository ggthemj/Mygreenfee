package com.legreenfee.legreenfeesdk;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LGFFPaymentActivity extends AppCompatActivity {

    String mClubName;
    String mClubId;
    String mDate;
    String mTime;
    String mTeeName;
    Double mPrice;
    int mPlayersNumber;
    EditText cardDateEditText;
    EditText cardNumberEditText;
    EditText securityCodeEditText;
    MonthYearPickerDialog pd;
    LinearLayout proceedPaymentButton;
    LinearLayout loadingOverlay;
    private Toolbar toolbar;
    String mCardNumber;
    String mSecurityCode;
    boolean cardExist = false;
    final static int PAYMENT_URL_ACTIVTY_REQUEST_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_activity);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.Payment));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        loadingOverlay = (LinearLayout) findViewById(R.id.loading_overlay);
        loadingOverlay.setVisibility(View.GONE);
        loadingOverlay.setOnTouchListener(new View.OnTouchListener() {

                                              @Override
                                              public boolean onTouch(View v, MotionEvent event) {
                                                  return true;
                                              }
                                          }
        );
        ImageView calendarIcon = (ImageView) findViewById(R.id.calendar_icon);
        Drawable normalDrawable = getResources().getDrawable(R.drawable.ic_today_black_48dp);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, getResources().getColor(R.color.colorPrimary));
        calendarIcon.setImageDrawable(wrapDrawable);



        TextView clubNameLabel = (TextView) findViewById(R.id.club_name_label);
        TextView teeNameLabel = (TextView) findViewById(R.id.course_name_label);
        final TextView dateLabel = (TextView) findViewById(R.id.date_label);
        TextView playersNumber = (TextView) findViewById(R.id.player_number_label);
        TextView priceLabel = (TextView) findViewById(R.id.price_label);

        View proceedPaymentButton = findViewById(R.id.payment_button_layout);
        proceedPaymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!validateForm())
                    return;
                loadingOverlay.setVisibility(View.VISIBLE);
                if (cardExist) {
                    mSecurityCode = securityCodeEditText.getText().toString();
                    MyGreenFeeKit.cardPayOrder(getApplicationContext(), MyGreenFeeKit.getCurrentOrder(), MyGreenFeeKit.getCurrentOrder().userInfo, mSecurityCode, new LGFFSDKCallBack<Void, String>() {
                        @Override
                        public Void onResponse(String param) {
                            loadingOverlay.setVisibility(View.GONE);
                            saveOrderAndFinish(true);
                            return null;
                        }

                        @Override
                        public void onError(LGFFError error) {
                            loadingOverlay.setVisibility(View.GONE);

                            if (error.kind == LGFFError.checkPaymentUrlneeded) {
                                startCheckUrlActivity(error.msg);
                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                }).setTitle(R.string.an_error_occurred);
                                if (error != null) {
                                    if (error.msg != null)
                                        builder.setMessage(error.msg);
                                }

                                AlertDialog dialog = builder.create();
                                dialog.show();
                            }
                        }
                    });
                } else {
                    mCardNumber = cardNumberEditText.getText().toString();
                    mSecurityCode = securityCodeEditText.getText().toString();
                    SimpleDateFormat dateFormater = new SimpleDateFormat("MM/yy", Locale.getDefault());
                    Date date = new Date();
                    try {
                        date = dateFormater.parse(cardDateEditText.getText().toString());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    MyGreenFeeKit.createCard(getApplicationContext(), MyGreenFeeKit.getCurrentOrder().userInfo.email, mCardNumber, date, mSecurityCode,
                            new LGFFSDKCallBack<Void, String>() {
                                @Override
                                public Void onResponse(String param) {

                                    MyGreenFeeKit.cardPayOrder(getApplicationContext(), MyGreenFeeKit.getCurrentOrder(), MyGreenFeeKit.getCurrentOrder().userInfo, mSecurityCode, new LGFFSDKCallBack<Void, String>() {
                                        @Override
                                        public Void onResponse(String param) {
                                            loadingOverlay.setVisibility(View.GONE);
                                            saveOrderAndFinish(true);
                                            return null;
                                        }

                                        @Override
                                        public void onError(LGFFError error) {
                                            loadingOverlay.setVisibility(View.GONE);

                                            if (error.kind == LGFFError.checkPaymentUrlneeded) {
                                                startCheckUrlActivity(error.msg);
                                            } else {
                                                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                                                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {

                                                    }
                                                }).setTitle(R.string.an_error_occurred);
                                                if (error != null) {
                                                    if (error.msg != null)
                                                        builder.setMessage(error.msg);
                                                }

                                                AlertDialog dialog = builder.create();
                                                dialog.show();
                                            }
                                        }
                                    });
                                    return null;
                                }

                                @Override
                                public void onError(LGFFError error) {
                                    loadingOverlay.setVisibility(View.GONE);
                                    AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                                    builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {

                                        }
                                    }).setTitle(R.string.an_error_occurred);
                                    if (error != null) {
                                        if (error.msg != null)
                                            builder.setMessage(error.msg);
                                    }

                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                }
                            });
                }


            }
        });

        Bundle b = getIntent().getExtras();
        mPrice = b.getDouble("price");
        mClubName = MyGreenFeeKit.getCurrentOrder().clubName;
        mClubId = MyGreenFeeKit.getCurrentOrder().clubId;
        mDate = MyGreenFeeKit.getCurrentOrder().date;
        mTime = MyGreenFeeKit.getCurrentOrder().time;
        mTeeName = MyGreenFeeKit.getCurrentOrder().teeName;
        mPlayersNumber = MyGreenFeeKit.getCurrentOrder().placeNumber;
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date = new Date();
        try {
            date = dateFormater.parse(mDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        dateFormater = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());

        clubNameLabel.setText(mClubName);
        teeNameLabel.setText(mTeeName);
        dateLabel.setText(dateFormater.format(date) + " " + mTime);
        playersNumber.setText(setPlayersLabel(mPlayersNumber));
        priceLabel.setText(String.format("%.2f €", mPrice));

        cardDateEditText = (EditText) findViewById(R.id.card_date_edit_text);
        cardDateEditText.setCursorVisible(false);
        cardDateEditText.setInputType(InputType.TYPE_NULL);

        cardNumberEditText = (EditText) findViewById(R.id.card_number_edit_text);
        securityCodeEditText = (EditText) findViewById(R.id.card_crypto_edit_text);

        pd = new MonthYearPickerDialog();
        pd.setListener(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String monthLabel;
                if (monthOfYear <= 9)
                    monthLabel = "0" + monthOfYear;
                else
                    monthLabel = "" + monthOfYear;
                cardDateEditText.setText(monthLabel + "/" + year);
            }
        });
        cardDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.show(getSupportFragmentManager(), "MonthYearPickerDialog");
            }
        });
        cardDateEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (pd.isVisible()) ;
                    pd.show(getSupportFragmentManager(), "MonthYearPickerDialog");
                }
            }
        });

        loadingOverlay.setVisibility(View.VISIBLE);
        MyGreenFeeKit.checkCard(this, MyGreenFeeKit.getCurrentOrder().userInfo.email, null, new LGFFSDKCallBack<Void, JSONObject>() {
            @Override
            public Void onResponse(JSONObject json) {
              /*  String expirationDate = null;
                String cardNumber = null;
                JSONObject card = null;
                try {
                     card = json.getJSONObject("card");

                if(card != null) {
                    if(card.has("expiration_date"))
                        expirationDate = card.getString("expiration_date");
                    if(card.has("alias"))
                        cardNumber = card.getString("alias");
                }
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
                loadingOverlay.setVisibility(View.GONE);
                cardExist = true;
               /* cardNumberEditText.setEnabled(false);
                cardNumberEditText.setBackgroundColor(getResources().getColor(R.color.background_grey));
                cardDateEditText.setEnabled(false);
                cardDateEditText.setBackgroundColor(getResources().getColor(R.color.background_grey));*/

                cardDateEditText.setFocusable(false);
                cardDateEditText.setFocusableInTouchMode(false);
                LinearLayout cardNumberLayout = (LinearLayout) findViewById(R.id.card_number_layout);
                cardNumberLayout.setVisibility(View.GONE);
                LinearLayout cardDateLayout = (LinearLayout) findViewById(R.id.card_date_layout);
                cardDateLayout.setVisibility(View.GONE);
                ((TextView) findViewById(R.id.crypto_info_label)).setVisibility(View.VISIBLE);


                securityCodeEditText.requestFocus();
              /*  if(expirationDate != null){
                    SimpleDateFormat dateFormater = new SimpleDateFormat("MMyy", Locale.getDefault());
                     Date date = null;

                    try {
                        date = dateFormater.parse(expirationDate);
                        dateFormater = new SimpleDateFormat("MM/yy", Locale.getDefault());

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    if(date != null)
                    cardDateEditText.setText( dateFormater.format(date));
                }

                if(cardNumber != null)
                    cardNumberEditText.setText(cardNumber);*/
                return null;
            }

            @Override
            public void onError(LGFFError error) {
                cardExist = false;
                loadingOverlay.setVisibility(View.GONE);
            }
        });

    }

    private String setPlayersLabel(int number) {
        if (number == 1)
            return getString(R.string._1_player);
        else return number + " " + getString(R.string.lu_players);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        if (id == android.R.id.home) {

            finishWithDialog();


        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        finishWithDialog();
    }


    public void finishWithDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton(R.string.Continue, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        }).setNegativeButton(R.string.give_up, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                loadingOverlay.setVisibility(View.VISIBLE);
                LGFFOrder.cancelOrder(LGFFPaymentActivity.this, MyGreenFeeKit.getCurrentOrder(), new LGFFSDKCallBack<Void, String>() {
                    @Override
                    public Void onResponse(String param) {
                        loadingOverlay.setVisibility(View.GONE);
                        saveOrderAndFinish(false);
                        return null;
                    }

                    @Override
                    public void onError(LGFFError error) {
                        loadingOverlay.setVisibility(View.GONE);
                        saveOrderAndFinish(false);
                    }
                });

            }
        }).setTitle(R.string.order_not_confirmed_yet);
        builder.setMessage(R.string.do_you_really_want_to_give_up_your_order);

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void startCheckUrlActivity(String url) {
        Intent intent = new Intent(LGFFPaymentActivity.this, PaymentUrlActivity.class);
        Bundle b = new Bundle();
        b.putString("url", url);
        intent.putExtras(b);
        startActivityForResult(intent, PAYMENT_URL_ACTIVTY_REQUEST_CODE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == PAYMENT_URL_ACTIVTY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                loadingOverlay.setVisibility(View.VISIBLE);
                MyGreenFeeKit.confirmOrder(getApplicationContext(), MyGreenFeeKit.getCurrentOrder(), MyGreenFeeKit.getCurrentOrder().userInfo, new LGFFSDKCallBack<Void, String>() {
                    @Override
                    public Void onResponse(String param) {
                        saveOrderAndFinish(true);
                        return null;
                    }

                    @Override
                    public void onError(LGFFError error) {
                        loadingOverlay.setVisibility(View.GONE);
                        AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                        builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        }).setTitle(R.string.an_error_occurred);
                        if (error != null) {
                            if (error.msg != null)
                                builder.setMessage(error.msg);
                        }

                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }
                });
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    private void saveOrderAndFinish(boolean save) {
        if (save) {
            MyGreenFeeKit.getDelegate().onBookingSucess(MyGreenFeeKit.getCurrentOrder(), null);
            Intent returnIntent = new Intent();
            setResult(Activity.RESULT_OK, returnIntent);
        } else {
            MyGreenFeeKit.setCurrentOrder(null);
        }
        finish();
    }


    private boolean validateForm() {
        String cardNumber = cardNumberEditText.getText().toString().trim().replace(" ", "");
        String securityCode = securityCodeEditText.getText().toString().trim().replace(" ", "");
        if (!cardExist) {
            if (cardNumber.length() < 13 || cardNumber.length() > 16) {
                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }).setTitle(R.string.an_error_occurred);
                builder.setMessage(R.string.the_credit_card_number_entered_is_not_valid_must_be_between_13_and_16_digits);

                AlertDialog dialog = builder.create();
                dialog.show();
                return false;
            }

            if (cardDateEditText.getText().toString().isEmpty()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

                builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                }).setTitle(R.string.an_error_occurred);
                builder.setMessage(R.string.please_enter_the_card_expiration_date);

                AlertDialog dialog = builder.create();
                dialog.show();
                return false;
            }

        }
        if (securityCode.length() < 3 || securityCode.length() > 4) {
            AlertDialog.Builder builder = new AlertDialog.Builder(LGFFPaymentActivity.this);

            builder.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                }
            }).setTitle(R.string.an_error_occurred);
            builder.setMessage(R.string.the_security_code_entered_is_not_valid_must_be_between_3_and_4_digits);
            AlertDialog dialog = builder.create();
            dialog.show();
            return false;
        }
        return true;
    }
}
