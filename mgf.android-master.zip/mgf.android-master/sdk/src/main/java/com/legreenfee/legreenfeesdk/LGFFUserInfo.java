package com.legreenfee.legreenfeesdk;

import java.util.Date;

/**
 * Created by user on 11/02/2016.
 */
public class LGFFUserInfo {

    String firstName;
    String lastName;
    String email;
    Date birthDate;
    String phone;

    public LGFFUserInfo() {

    }

    public LGFFUserInfo(String firstName, String lastName, String email, Date birthDate, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.birthDate = birthDate;
        this.phone = phone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
