package com.legreenfee.legreenfeesdk;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by user on 08/02/2016.
 */
public class LGFFTee {
    String publicId;
    String name;


    public LGFFTee(JSONObject json) {

        try {
            if(!json.isNull("public_id"))
                this.publicId = json.getString("public_id");
            if(!json.isNull("name"))
                this.name = json.getString("name");


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    /* package */ static ArrayList<LGFFTee> parseJson(JSONArray json) {
        ArrayList<LGFFTee> tees = new  ArrayList<LGFFTee>();

        try {

                for (int i = 0; i < json.length(); i++) {

                    tees.add(new LGFFTee(json.getJSONObject(i)));
                }

            }
         catch (JSONException e) {
            e.printStackTrace();
        }
        return tees;
    }
}
