package com.legreenfee.legreenfeesdk;

import android.content.Context;

import java.util.Calendar;
import java.util.Date;

public abstract class LGFFBookingDelegate {


    public abstract LGFFUserInfo getUserInfo();

    public Date getDefaultDate(){
        Calendar now = Calendar.getInstance();

        int hour = now.get(Calendar.HOUR_OF_DAY);
        if(hour >= 18)
            now.add(Calendar.DATE, 1);

        return now.getTime();
    }

    public String getDefaultDiscountId(){
        return null;
    }



    public void onUserInfoAccepted(){

    }

    public void onBookingSucess(LGFFOrder order, String transactionID){

    }

    public void onBookingFailled(Context context, LGFFError error, Runnable reloadCallBack){

    }

    public void onBookingActivityFinished(){

    }


}
