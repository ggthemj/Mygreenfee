package com.legreenfee.legreenfeesdk;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LGFFOrder implements Comparable<LGFFOrder>{

    public String orderID;
    public String date;
    public String time;
    public Integer placeNumber;
    public String discountId;
    public String clubId;
    public String clubName;
    public String teeID;
    public String teeName;
    public LGFFUserInfo userInfo;


    public LGFFOrder(String jsonOrder) {


            try {
                JSONObject jsonObject = new JSONObject(jsonOrder);
                if(jsonObject.has("order_id"))
                this.orderID = jsonObject.getString("order_id");
            } catch (JSONException e) {
                e.printStackTrace();
            }

    }

    public LGFFOrder(String date, String time, Integer placeNumber, String discountId, String clubId, String clubName, String teeID, String teeName, LGFFUserInfo userInfo) {

        this.date = date;
        this.placeNumber = placeNumber;
        this.discountId = discountId;
        this.clubId = clubId;
        this.clubName = clubName;
        this.teeID = teeID;
        this.teeName = teeName;
        this.userInfo = userInfo;
        this.time = time;
    }

    /* package */ static void postOrder(Context context, LGFFOrder order, LGFFUserInfo user, LGFFSDKCallBack <Void, String>callBack){
       MyGreenFeeKit.getNetworkManager().postOrder(context, order, user, callBack);
    }

    /* package */ static void cancelOrder(Context context, LGFFOrder order, LGFFSDKCallBack <Void, String>callBack){
        MyGreenFeeKit.getNetworkManager().cancelOrder(context, order, callBack);
    }

    public static JSONObject toJson(LGFFOrder order){
        JSONObject object = new JSONObject();
        try {
            object.put("clubId", order.clubId);
            object.put("placeNumber", order.placeNumber);
            object.put("date", order.date);
            object.put("teeID", order.teeID);
            object.put("discountId", order.discountId);
            object.put("clubName", order.clubName);
            object.put("teeName", order.teeName);
            object.put("time", order.time);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }

    public static LGFFOrder fromJson(JSONObject object){
        String date = "";
        String time = "";
        Integer placeNumber = 1;
        String discountId = "";
        String clubId = "";
        String clubName = "";
        String teeID = "";
        String teeName = "";


            try {

                if(object.has("date"))
                    date = object.getString("date");

                if(object.has("time"))
                    time = object.getString("time");

                if(object.has("placeNumber"))
                    placeNumber = object.getInt("placeNumber");

                if(object.has("discountId"))
                    discountId = object.getString("discountId");

                if(object.has("clubId"))
                    clubId = object.getString("clubId");

                if(object.has("clubName"))
                    clubName = object.getString("clubName");

                if(object.has("teeID"))
                    teeID = object.getString("teeID");

                if(object.has("teeName"))
                    teeName = object.getString("teeName");

            } catch (JSONException e) {
                e.printStackTrace();
            }
        LGFFOrder order = new LGFFOrder(date, time, placeNumber, discountId, clubId, clubName, teeID, teeName, null);
        return order;
    }

    @Override
    public int compareTo(LGFFOrder another) {
        Locale currentLocale = MyGreenFeeKit.getLocale();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm", currentLocale);
        Date date = new Date();
        Date date2 = new Date();
        try {
            date = dateFormatter.parse(this.date + " " + this.time);
            date2 = dateFormatter.parse(another.date + " " + another.time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date.compareTo(date2);
    }
}
