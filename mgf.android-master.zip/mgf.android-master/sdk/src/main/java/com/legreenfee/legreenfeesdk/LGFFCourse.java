package com.legreenfee.legreenfeesdk;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by user on 08/02/2016.
 */
public class LGFFCourse {
    String publicId;
    String clubPublicId;
    String name;
    ArrayList<LGFFTee> tees;


    public LGFFCourse(JSONObject json) {

        try {
            if(!json.isNull("public_id"))
                this.publicId = json.getString("public_id");
            if(!json.isNull("name"))
                this.name = json.getString("name");
            if(!json.isNull("club_public_id"))
                this.clubPublicId = json.getString("club_public_id");
            if(!json.isNull("tees")){
                this.tees = LGFFTee.parseJson(json.getJSONArray("tees"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    public static ArrayList<LGFFCourse> parseJson(JSONObject json) {
        ArrayList<LGFFCourse> courses = new  ArrayList<LGFFCourse>();
        JSONArray jsonCourses;
        try {
            if(json.has("courses")){
                jsonCourses = json.getJSONArray("courses");
                for (int i = 0; i < jsonCourses.length(); i++) {

                    courses.add(new LGFFCourse(jsonCourses.getJSONObject(i)));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return courses;
    }



    public static void getCourses(Context context, String clubId, LGFFSDKCallBack <Void, ArrayList<LGFFCourse>>callBack){
        MyGreenFeeKit.getNetworkManager().getCourses(context, clubId, callBack);
    }
}
