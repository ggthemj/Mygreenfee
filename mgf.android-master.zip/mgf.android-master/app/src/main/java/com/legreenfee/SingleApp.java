package com.legreenfee;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;
import com.legreenfee.legreenfeesdk.LGFFClub;
import com.legreenfee.legreenfeesdk.LGFFDiscount;
import com.legreenfee.legreenfeesdk.LGFFOrder;
import com.legreenfee.legreenfeesdk.LGFFUserInfo;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

/**
 * Created by user on 07/02/2016.
 */
public class SingleApp {
    private static ArrayList<LGFFClub> clubs = new ArrayList<>();
    private static ArrayList<LGFFOrder> orders = new ArrayList<>();
    public static Location currentLocation;



    private static Context applicationContext;


    public static ArrayList<LGFFClub> getClubs(){
        return SingleApp.clubs;
    }

    public static void setClubs(ArrayList<LGFFClub> clubs) {
        SingleApp.clubs = clubs;

//        { // TODO: Do we want this ?
//            SingleApp.clubs.clear();
//            SingleApp.clubs.addAll(clubs);
//        }
    }

    public static LGFFClub getClubById(String id){

        for(LGFFClub c : SingleApp.clubs){
            if(c.clubID.equals(id))
                return c;
        }
        return null;
    }


    public static void saveUserInfo(LGFFUserInfo user, Context context){
        LGFFSharedPreferences.saveUserInfo(user, context);
    }

    public static LGFFUserInfo loadUserInfo(Context context){
        return LGFFSharedPreferences.loadUserInfo(context);
    }

    public static ArrayList<LGFFOrder> getRecentOrders(Context context){
        ArrayList<LGFFOrder> recentOrders = new ArrayList<>();
        for(LGFFOrder o : getOrders(context)){
            Locale currentLocale = context.getResources().getConfiguration().locale;
            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm", currentLocale);
            Date date = new Date();
            Date today = new Date();
            try {
              date  = dateFormatter.parse(o.date + " " + o.time);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if((today.getTime() - date.getTime()) < (24 * 60 * 60 * 1000))
                recentOrders.add(o);
        }
        return recentOrders;
    }

    public static ArrayList<LGFFOrder> getOrders(Context context){


        loadOrders(context);
        Collections.sort(SingleApp.orders);
        return SingleApp.orders;
    }

    public static void addOrder(LGFFOrder order, Context context){

        SingleApp.orders.add(order);
        saveOrders(context);
    }

    private static void saveOrders(Context context){
        JSONArray array = new JSONArray();
        for(LGFFOrder o : SingleApp.orders){
            array.put(LGFFOrder.toJson(o));
        }
        LGFFSharedPreferences.saveOrders(array, context);
    }


    private static void loadOrders(Context context){
       JSONArray array  = LGFFSharedPreferences.loadOrders(context);
        SingleApp.orders.clear();

            try {
                for(int i = 0; i < array.length(); i++){
                    orders.add(LGFFOrder.fromJson(array.getJSONObject(i)));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


    public static double distance(Location position, LatLng EndP) {
        Location dest = new Location("dest");
        dest.setLatitude(EndP.latitude);
        dest.setLongitude(EndP.longitude);
        dest.setTime(new Date().getTime()); //Set time as current Date
        return position.distanceTo(dest);
    }

    public static ArrayList<LGFFClub> getNearbyClubs(Location position, int maxNumber){

        if(SingleApp.getClubs().size() > 0)
        {
            ArrayList<LGFFClub> sortedGolfs = (ArrayList<LGFFClub>)SingleApp.clubs.clone();
            final Location pos = position;
            Collections.sort(sortedGolfs, new Comparator<LGFFClub>() {
                public int compare(LGFFClub g1, LGFFClub g2) {
                    return Double.compare(
                            distance(pos, (new LatLng(g1.lat, g1.lng))),
                            distance(pos, (new LatLng(g2.lat, g2.lng))));
                }
            });
            if(sortedGolfs.size() >= maxNumber)
                return new ArrayList(sortedGolfs.subList(0, maxNumber - 1));
            else
                return sortedGolfs;

        }
        else
            return new ArrayList<>();
    }


    public static void setApplicationContext(Context applicationContext) {
        SingleApp.applicationContext = applicationContext;
    }

    public static Context getApplicationContext() {
        return applicationContext;
    }
}