package com.legreenfee;
import android.animation.Animator;
import android.content.Context;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import android.widget.RelativeLayout;

public class BottomSheet extends RelativeLayout {
    private static final Interpolator INTERPOLATOR = new FastOutSlowInInterpolator();
    private static final int TRANSLATION_DURATION = 200;

    @Override
    public boolean isShown() {
        return isShown;
    }

    private boolean isShown;

    public BottomSheet(Context context) {
        super(context);
        init();
    }

    public BottomSheet(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BottomSheet(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        isShown = false;
       // hide(0);
    }

    public void hide(){
        hide(TRANSLATION_DURATION);
    }

    private void hide(int duration) {
        //Log.d("bottom_sheet_test", " bottom_shit hide() : getheight: " + BottomSheet.this.getHeight());
        ViewPropertyAnimator animator = BottomSheet.this.animate()
                .translationY(BottomSheet.this.getHeight())
                .setInterpolator(INTERPOLATOR)
                .setDuration(duration);


        animator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                // Prevent drawing the View after it is gone
                BottomSheet.this.setVisibility(View.GONE);
                isShown = false;
            }

            @Override
            public void onAnimationCancel(Animator animator) {
                // Canceling a hide should show the view
                show();
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });

        animator.start();
    }

    public void show() {
        ViewPropertyAnimator animator = this.animate()
                .translationY(0)
                .setInterpolator(INTERPOLATOR)
                .setDuration(TRANSLATION_DURATION);

        animator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
                isShown = true;
                BottomSheet.this.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animator animator) {

            }

            @Override
            public void onAnimationCancel(Animator animator) {
                hide();
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });

        animator.start();
    }
}
