package com.legreenfee;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.legreenfee.legreenfeesdk.LGFFBookingActivity;
import com.legreenfee.legreenfeesdk.LGFFBookingDelegate;
import com.legreenfee.legreenfeesdk.LGFFClub;
import com.legreenfee.legreenfeesdk.LGFFError;
import com.legreenfee.legreenfeesdk.LGFFOrder;
import com.legreenfee.legreenfeesdk.LGFFPaymentActivity;
import com.legreenfee.legreenfeesdk.LGFFUserInfo;
import com.legreenfee.legreenfeesdk.MyGreenFeeKit;

import java.util.Calendar;
import java.util.Date;


public class ClubDetailActivity extends AppCompatActivity implements OnMapReadyCallback {

    private SupportMapFragment fragment;
    private MapView mapView;
    private GoogleMap mMap;
    private String clubId = "";
    private LGFFClub club;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_detail);

        Bundle bundle= getIntent().getExtras();
        if(bundle.getString("club_id") != null)
            clubId = bundle.getString("club_id");
        club = SingleApp.getClubById(clubId);
        mapView = (MapView) findViewById(R.id.map_lite);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        mapView.setVisibility(View.GONE);





        ((TextView)findViewById(R.id.description_label)).setText(club.detailedDescription);
        ((TextView)findViewById(R.id.club_addresse_label)).setText(club.address);
        ((TextView)findViewById(R.id.club_addresse_label)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("http://maps.google.com/maps?daddr=" + club.address)  );
                startActivity(intent);
            }
        });

        ((TextView)findViewById(R.id.club_url_label)).setText(club.url);
        ((TextView)findViewById(R.id.club_url_label)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(club.url != null && club.url.length() != 0){
                    Uri uri;
                    if(club.url.contains("http://"))
                        uri = Uri.parse(club.url); // missing 'http://' will cause crashed
                    else
                        uri = Uri.parse("http://" + club.url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                }
            }
        });
        ((TextView)findViewById(R.id.club_mail_label)).setText(club.email);
        ((TextView)findViewById(R.id.club_mail_label)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (club.email != null && club.email.length() != 0) {
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setData(Uri.parse("mailto:" + club.email)); // only email apps should handle this
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                    }
                }
            }
        });

        CollapsingToolbarLayout collapsingToolbar = (CollapsingToolbarLayout)findViewById(R.id.collapsingToolbarLayout);
        collapsingToolbar.setTitle(club.name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        AppBarLayout appBar = (AppBarLayout) findViewById(R.id.appbar);
        appBar.setExpanded(true, false);



        FrameLayout bookingButton = (FrameLayout)findViewById(R.id.booking_button_layout);
        bookingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LGFFBookingDelegate delegate = new LGFFBookingDelegate() {


                    @Override
                    public LGFFUserInfo getUserInfo() {
                        return  SingleApp.loadUserInfo(SingleApp.getApplicationContext());
                    }

                    @Override
                    public void onBookingFailled(Context context, LGFFError error, Runnable reloadUserCallBack) {

                        if(error.kind != LGFFError.networkError){
                        UserFormManager.setReloadUserInfo(reloadUserCallBack);
                        UserFormManager.setError(error);
                        if(!UserFormManager.isUserFormActivityLaunched()){
                                Intent intent = new Intent(context, UserFormActivity.class);
                                context.startActivity(intent);

                        }else{
                           Message msg = new Message();
                            msg.what = UserFormManager.MSG_FAIL;
                            UserFormManager.getUserInfoActivityHandler().sendMessage(msg);
                        }
                        }

                    }

                    @Override
                    public void onUserInfoAccepted() {
                        if(UserFormManager.isUserFormActivityLaunched()){
                            Message msg = new Message();
                            msg.what = UserFormManager.MSG_SUCCESS;
                            UserFormManager.getUserInfoActivityHandler().sendMessage(msg);
                        }

                    }

                    @Override
                    public void onBookingSucess(LGFFOrder order, String transactionID) {
                        if(order != null)
                            SingleApp.addOrder(order, getApplicationContext());
                    }
                };

                MyGreenFeeKit.startBookingActivity(ClubDetailActivity.this, club, delegate);
            }
        });
    }



    @Override
    public void onResume() {

        super.onResume();


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        mMap.getUiSettings().setMapToolbarEnabled(false);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(club.lat, club.lng), 16));
        mapView.setVisibility(View.VISIBLE);
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                //prevent redirection on GoogleMap app
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE) {
            if(resultCode == Activity.RESULT_OK){
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
        }
    }
}
