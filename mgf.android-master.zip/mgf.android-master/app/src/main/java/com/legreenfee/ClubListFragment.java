package com.legreenfee;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.legreenfee.legreenfeesdk.LGFFClub;
import com.legreenfee.legreenfeesdk.MyGreenFeeKit;

import java.text.Normalizer;
import java.util.ArrayList;


public class ClubListFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private ClubAdapter mAdapter;
    private SearchView actionBarSearchView;

//    private ArrayList<LGFFClub> filteredGolfList  = new ArrayList<LGFFClub>();

    private ArrayList<LGFFClub> currentGolfList  = new ArrayList<LGFFClub>();

    public ClubListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        setHasOptionsMenu(true);
        View rootView = inflater.inflate(R.layout.fragment_club_list, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);

        mLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);


        currentGolfList.clear();
        currentGolfList.addAll(SingleApp.getClubs());


        mAdapter = new ClubAdapter(currentGolfList, getContext());
        mAdapter.setOnItemClickListener(new ClubAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                Intent intent = new Intent(getActivity(), ClubDetailActivity.class);
                Bundle b = new Bundle();
                b.putString("club_id", currentGolfList.get(position).clubID); //Your id
                intent.putExtras(b); //Put your id to your next Intent
                getActivity().startActivityForResult(intent, MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE);


            }
        });
        reloadList(null);
        mRecyclerView.setAdapter(mAdapter);
        return rootView;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        //Log.d("fragment_test", "################ClubListFrament onAttach##################");
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    private SearchView.OnQueryTextListener searchQueryListener = new SearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            return onQueryTextChange(query);
        }

        @Override
        public boolean onQueryTextChange(String query) {
            reloadList(query);
            return true;
        }

    };


        private void reloadList(String query){
            currentGolfList.clear();
            if(query != null){
                if(query.length() == 0){
                    if(SingleApp.currentLocation != null)
                        currentGolfList.addAll(SingleApp.getNearbyClubs(SingleApp.currentLocation, 15));
                    else
                        currentGolfList.addAll(SingleApp.getClubs());
                }
                else{

                currentGolfList.addAll(filterGolf(query));
                }
            }
            else {
                if(SingleApp.currentLocation != null)
                    currentGolfList.addAll(SingleApp.getNearbyClubs(SingleApp.currentLocation, 15));
                else
                    currentGolfList.addAll(SingleApp.getClubs());
            }
            mAdapter.notifyDataSetChanged();
        }


        @NonNull
        private ArrayList<LGFFClub> filterGolf(CharSequence constraint){
            final ArrayList<LGFFClub> results = new ArrayList<LGFFClub>();
            final ArrayList<LGFFClub> orig = SingleApp.getClubs();
            if (constraint != null) {
                if (orig != null) {
                    for (final LGFFClub g : orig) {
                        if (stripAccents(g.name.toLowerCase()
                        ).contains(stripAccents(constraint.toString().toLowerCase())))
                            results.add(g);
                        else if (g.address.toLowerCase()
                                .contains(constraint.toString()))
                            results.add(g);
                    }
                }
            }
//            filteredGolfList = (ArrayList<LGFFClub>) results;
            return results;
        }


    private String stripAccents(String src){
        src = Normalizer.normalize(src, Normalizer.Form.NFD);
        src = src.replaceAll("[^\\p{ASCII}]", "");
        return src;
    }


        @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);

        MenuItem searchItem;
        searchItem = menu.findItem(R.id.action_search);
        if(searchItem != null){
            actionBarSearchView = (SearchView) MenuItemCompat.getActionView(searchItem);
            actionBarSearchView.setOnQueryTextListener(searchQueryListener);
        }
    }



        @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.club_list_menu, menu);
        MenuItemCompat.expandActionView(menu.findItem(R.id.action_search));


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        //noinspection SimplifiableIfStatement
        if (id == R.id.map_action) {
            hideSoftKeyboard(getActivity());
            final TaskDelayer taskDelayer = new TaskDelayer(new Runnable() {
                @Override
                public void run() {

                    getActivity().getSupportFragmentManager().popBackStack();
                }
            }, 250);


            taskDelayer.startDelayedTask();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }
}
