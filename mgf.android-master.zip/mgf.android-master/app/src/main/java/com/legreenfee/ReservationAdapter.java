package com.legreenfee;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.legreenfee.legreenfeesdk.LGFFOrder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by user on 14/02/2016.
 */
public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder>  {
    private static ClickListener clickListener;
    private ArrayList<LGFFOrder> mDataset = new ArrayList<LGFFOrder>();
    private Context mContext;
    private Locale currentLocale;
    private SimpleDateFormat dateFormatter;
    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener {
        // each data item is just a string in this case
        public TextView club_name;
        public TextView date;
        public TextView course;
        public TextView players;
        public ImageView date_icon;
        public ImageView course_icon;

        public ViewHolder(View itemView) {
            super(itemView);
            club_name = (TextView)itemView.findViewById(R.id.club_name_label);
            date = (TextView)itemView.findViewById(R.id.reservation_date_label);
            course = (TextView)itemView.findViewById(R.id.reservation_course_name_label);
            players = (TextView)itemView.findViewById(R.id.player_number_label);
            date_icon = (ImageView)itemView.findViewById(R.id.date_icon);
            course_icon = (ImageView)itemView.findViewById(R.id.course_icon);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }

    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public ReservationAdapter(ArrayList<LGFFOrder> orders, Context context) {
        mDataset = orders;
        mContext = context;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public ReservationAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                            int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reservation_row, parent, false);
        // set the view's size, margins, paddings and layout parameters


        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        currentLocale = mContext.getResources().getConfiguration().locale;
        dateFormatter = new SimpleDateFormat("yyyy-MM-dd", currentLocale);
        String dateString = "";
        try {
            Date date = dateFormatter.parse(mDataset.get(position).date);
            dateFormatter = new SimpleDateFormat("dd MMMM yyyy", currentLocale);
            dateString = dateFormatter.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.club_name.setText(mDataset.get(position).clubName);
        holder.date.setText(dateString + "  " + mDataset.get(position).time);

        holder.course.setText(mDataset.get(position).teeName);
        if(mDataset.get(position).placeNumber == 1)
            holder.players.setText(mContext.getString(R.string._1_player));
        else
            holder.players.setText(mDataset.get(position).placeNumber.toString() + " " + mContext.getString(R.string.lu_players));



        Drawable normalDrawable = mContext.getResources().getDrawable(R.drawable.ic_today_black_48dp);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, mContext.getResources().getColor(R.color.colorPrimary));
        holder.date_icon.setImageDrawable(wrapDrawable);




    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }
    public void setOnItemClickListener(ClickListener clickListener) {
        ReservationAdapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

}


