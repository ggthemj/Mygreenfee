package com.legreenfee;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.gms.maps.GoogleMap;
import com.legreenfee.legreenfeesdk.MyGreenFeeKit;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener  {

    private GoogleMap mMap;
    private  Toolbar toolbar;
    private MapFragment mapFragment;
    private boolean shouldShowReservationsFragment = false;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);







        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(0).setChecked(true);
        mapFragment= new MapFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, mapFragment).addToBackStack("map_fragment").commit();

    }

    public void setActionBarTitle(String title){
        if(title != null){
            toolbar.setLogo(null);
            toolbar.setTitle(title);
        }else{

            toolbar.setLogo(R.drawable.logo_mygreenfee);
            toolbar.setTitle("");
        }
    }






    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }else if (mapFragment != null && mapFragment.bottomSheet != null && getSupportFragmentManager().getBackStackEntryCount() <=1  && mapFragment.bottomSheet.isShown()){
                    mapFragment.bottomSheet.hide();
        } else{
            if(getSupportFragmentManager().getBackStackEntryCount() > 1 ){
                NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
                navigationView.getMenu().getItem(0).setChecked(true);
            }
            if(getSupportFragmentManager().getBackStackEntryCount() <=1)
                finish();
            super.onBackPressed();
        }
    }





    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if(getSupportFragmentManager().getBackStackEntryCount() > 1)
            getSupportFragmentManager().popBackStack();
        if (id == R.id.nav_golfs) {


        } else if (id == R.id.nav_reservations) {
            Fragment fragment = new ReservationFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, fragment).addToBackStack("reservation_fragment").commit();
        } else if (id == R.id.nav_account) {
            // Create new fragment and transaction
            Fragment fragment = new AccountFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, fragment).addToBackStack("account_fragment").commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        return false;
    }

    @Override
    public void onResume(){
        super.onResume();
        if(shouldShowReservationsFragment){
            shouldShowReservationsFragment = false;
            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.getMenu().getItem(1).setChecked(true);
            onNavigationItemSelected(navigationView.getMenu().getItem(1));

        }




    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MapFragment.REQUEST_LOCATION){
            mapFragment.onActivityResult(requestCode, resultCode, data);
        }
        else if (requestCode == MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE) {
            if(resultCode == Activity.RESULT_OK){
                shouldShowReservationsFragment = true;

            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mapFragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
