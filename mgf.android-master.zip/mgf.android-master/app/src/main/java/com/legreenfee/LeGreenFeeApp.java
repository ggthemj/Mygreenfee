package com.legreenfee;

import android.app.Application;

/**
 * Created by user on 26/02/2016.
 */
public class LeGreenFeeApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        SingleApp.setApplicationContext(getApplicationContext());
    }
}
