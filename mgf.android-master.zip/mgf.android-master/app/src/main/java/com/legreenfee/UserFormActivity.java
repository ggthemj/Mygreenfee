package com.legreenfee;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.legreenfee.legreenfeesdk.LGFFClub;
import com.legreenfee.legreenfeesdk.LGFFError;
import com.legreenfee.legreenfeesdk.LGFFUserInfo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UserFormActivity extends AppCompatActivity {

    private  Toolbar toolbar;
    private Date selectedDate;
    private DatePickerDialog dateDialog;
    private EditText birdthday_edit_text;
    private EditText name_edit_text;
    private EditText first_name_edit_text;
    private EditText email_edit_text;
    private EditText phone_edit_text;
    private Locale currentLocale;
    private LGFFError error;
    private View loadingOverlay;

    Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.custom_toast_view,
                    (ViewGroup) findViewById(R.id.toast_layout_root));

            TextView text = (TextView) layout.findViewById(R.id.text);
            if(msg.what == UserFormManager.MSG_FAIL){

                manageErrors();
            }else if(msg.what == UserFormManager.MSG_SUCCESS) {



            text.setText(R.string.saved);

            Toast toast = new Toast(UserFormActivity.this);
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setView(layout);
            toast.show();
                finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_form);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.Account));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        UserFormManager.setUserInfoActivityHandler(handler);
        error = UserFormManager.getError();
        invalidateOptionsMenu();

        loadingOverlay = findViewById(R.id.loading_overlay);
        loadingOverlay.setVisibility(View.GONE);
        loadingOverlay.setOnTouchListener(new View.OnTouchListener() {

                                             @Override
                                             public boolean onTouch(View v, MotionEvent event) {
                                                 return true;
                                             }
                                         }
        );

        name_edit_text = (EditText) findViewById(R.id.name_edit_text);;
        first_name_edit_text = (EditText)findViewById(R.id.first_name_edit_text);;
        email_edit_text = (EditText)findViewById(R.id.email_edit_text);;
        phone_edit_text = (EditText)findViewById(R.id.phone_edit_text);;
        birdthday_edit_text = (EditText)findViewById(R.id.birdthday_edit_text);

        LGFFUserInfo user = SingleApp.loadUserInfo(SingleApp.getApplicationContext());
        if(user != null){
            name_edit_text.setText(user.getLastName());
            first_name_edit_text.setText(user.getFirstName());
            email_edit_text.setText(user.getEmail());
            phone_edit_text.setText(user.getPhone());
            setDateText(user.getBirthDate());
        }




        birdthday_edit_text.setCursorVisible(false);
        birdthday_edit_text.setInputType(InputType.TYPE_NULL);

        Calendar newCalendar = Calendar.getInstance();
        dateDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                selectedDate = newDate.getTime();
                setDateText(newDate.getTime());

            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        birdthday_edit_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dateDialog.show();
            }
        });
        birdthday_edit_text.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (!dateDialog.isShowing())
                        dateDialog.show();
                }
            }
        });


        manageErrors();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        menu.clear();
        inflater.inflate(R.menu.account_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        if (id  == android.R.id.home) {
            finish();
        }

        if (id == R.id.save_action) {
            loadingOverlay.setVisibility(View.VISIBLE);
            LGFFUserInfo user = new LGFFUserInfo();
            if(first_name_edit_text.getText() != null)
                user.setFirstName(first_name_edit_text.getText().toString());
            if(name_edit_text.getText() != null)
                user.setLastName(name_edit_text.getText().toString());
            if(email_edit_text.getText() != null)
                user.setEmail(email_edit_text.getText().toString());
            if(phone_edit_text.getText() != null)
                user.setPhone(phone_edit_text.getText().toString());
            if(selectedDate!= null)
                user.setBirthDate(selectedDate);


            SingleApp.saveUserInfo(user, SingleApp.getApplicationContext());
            UserFormManager.getReloadUserInfo().run();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void setDateText(Date date) {
        if(date != null) {
            currentLocale = getResources().getConfiguration().locale;
            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", currentLocale);
            birdthday_edit_text.setText(dateFormatter.format(date.getTime()));
        }
    }




    @Override
    protected void onDestroy() {
        UserFormManager.setUserInfoActivityHandler(null);
        super.onDestroy();
    }

    private void manageErrors(){
        loadingOverlay.setVisibility(View.GONE);
        LGFFError error = UserFormManager.getError();
        boolean focused = false;
        if(error != null){

            if(error.kind == LGFFError.networkError){

            }

            if ((error.kind & LGFFError.missingLastName) == LGFFError.missingLastName){
                if(!focused){
                    name_edit_text.setFocusableInTouchMode(true);
                    name_edit_text.requestFocus();
                    focused =true;
                }
                name_edit_text.setError(getString(R.string.please_provide_a_last_name));
                }
            if ((error.kind & LGFFError.missingFirstName) == LGFFError.missingFirstName){

                if(!focused){
                    first_name_edit_text.setFocusableInTouchMode(true);
                    first_name_edit_text.requestFocus();
                    focused =true;
                }
                first_name_edit_text.setError(getString(R.string.please_provide_a_first_name));
            }
            if ((error.kind & LGFFError.missingBirthday) == LGFFError.missingBirthday){
                birdthday_edit_text.setError(getString(R.string.please_provide_a_birthday));

            }
            if ((error.kind & LGFFError.missingEmail) == LGFFError.missingEmail){

                if(!focused){
                    email_edit_text.setFocusableInTouchMode(true);
                    email_edit_text.requestFocus();
                    focused =true;
                }
                email_edit_text.setError(getString(R.string.please_provide_an_email));
            }
            if ((error.kind & LGFFError.invalideEmail) == LGFFError.invalideEmail){
                if(!focused){
                    email_edit_text.setFocusableInTouchMode(true);
                    email_edit_text.requestFocus();
                    focused =true;
                }
                email_edit_text.setError(getString(R.string.please_provide_a_valid_email));
            }


        }
    }
}
