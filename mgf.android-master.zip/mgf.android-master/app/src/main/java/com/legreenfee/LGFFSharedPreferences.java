package com.legreenfee;

import android.content.Context;
import android.content.SharedPreferences;

import com.legreenfee.legreenfeesdk.LGFFUserInfo;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Date;

/**
 * Created by user on 11/02/2016.
 */
public class LGFFSharedPreferences {

    private static SharedPreferences prefs = null;
    private static final Object lock = new Object();

    private static SharedPreferences getSharedPreferences(Context context){
        if(prefs == null)
            prefs = context.getSharedPreferences("com.legreenfee.app", Context.MODE_PRIVATE);
        return prefs;
    }

    public static void saveUserInfo(LGFFUserInfo user, Context context){
        synchronized (lock) {
            SharedPreferences.Editor editor =  getSharedPreferences(context).edit().putString("firstname", user.getFirstName())
                    .putString("lastname", user.getLastName())
                    .putString("email", user.getEmail())
                    .putString("phone", user.getPhone());


            if(user.getBirthDate() != null)
                editor.putLong("birthdate", user.getBirthDate().getTime());
            editor.commit();
        }

    }

    public static LGFFUserInfo loadUserInfo(Context context){
        synchronized (lock) {
            LGFFUserInfo user = new LGFFUserInfo();
            user.setFirstName(getSharedPreferences(context).getString("firstname", ""));
            user.setLastName(getSharedPreferences(context).getString("lastname", ""));
            user.setEmail(getSharedPreferences(context).getString("email", ""));
            user.setPhone(getSharedPreferences(context).getString("phone", ""));
            Long timestamp = getSharedPreferences(context).getLong("birthdate", 0);
            if(timestamp != 0)
                user.setBirthDate(new Date(timestamp));


            return user;
        }

    }


    public static void saveOrders(JSONArray orders, Context context){
        synchronized (lock) {
            SharedPreferences.Editor editor =  getSharedPreferences(context).edit()
                    .putString("orders", orders.toString());
            editor.commit();
        }

    }


    public static JSONArray loadOrders(Context context){
        synchronized (lock) {
            JSONArray array = null;
            try {
                array = new JSONArray(getSharedPreferences(context).getString("orders", ""));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(array == null)
                return new JSONArray();
            return array;
        }

    }
}
