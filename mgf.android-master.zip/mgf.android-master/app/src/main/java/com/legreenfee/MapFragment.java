package com.legreenfee;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.legreenfee.legreenfeesdk.LGFFBookingActivity;
import com.legreenfee.legreenfeesdk.LGFFBookingDelegate;
import com.legreenfee.legreenfeesdk.LGFFClub;
import com.legreenfee.legreenfeesdk.LGFFError;
import com.legreenfee.legreenfeesdk.LGFFOrder;
import com.legreenfee.legreenfeesdk.LGFFSDKCallBack;
import com.legreenfee.legreenfeesdk.LGFFUserInfo;
import com.legreenfee.legreenfeesdk.MyGreenFeeKit;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;


public class MapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener {
    private OnFragmentInteractionListener mListener;
    private SupportMapFragment fragment;
    private MapView mapView;
    private GoogleMap mMap;
    private boolean mapIsReady = false;
    public BottomSheet bottomSheet;
    private LinearLayout findClubsButton;
    private boolean showClubsButton = false;
    private View rootView;
    private LayoutInflater layoutInflater;
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private PendingResult<LocationSettingsResult> result;
    final static int REQUEST_LOCATION = 199;
    private LGFFSDKCallBack getClubsCallBack;
    private LinearLayout loadingLayout;
    private FloatingActionButton fab;
    private  View sheetView;
    private ArrayList<Marker> markers = new ArrayList<Marker>();
    final public static int MY_PERMISSIONS_REQUEST_ACCESS_LOCATION = 123;
    private GestureDetector gdt;
    private String selectedClubId;
    private boolean newScroll = false;



    public void onSaveInstanceState(Bundle outState){
        //This MUST be done before saving any of your own or your base class's variables
        final Bundle mapViewSaveState = new Bundle(outState);
        mapView.onSaveInstanceState(mapViewSaveState);
        outState.putBundle("mapViewSaveState", mapViewSaveState);
        //Add any other variables here.
        super.onSaveInstanceState(outState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.map_fragment, container, false);


        setHasOptionsMenu(true);

        final Bundle mapViewSavedInstanceState = savedInstanceState != null ? savedInstanceState.getBundle("mapViewSaveState") : null;

        mapView = (MapView) rootView.findViewById(R.id.map);
        mapView.onCreate(mapViewSavedInstanceState);
        mapView.getMapAsync(this);


        loadingLayout = (LinearLayout) rootView.findViewById(R.id.loading_overlay);
        loadingLayout.setVisibility(View.GONE);
        loadingLayout.setOnTouchListener(new View.OnTouchListener() {

                                             @Override
                                             public boolean onTouch(View v, MotionEvent event) {
                                                 return true;
                                             }
                                         }
        );


        gdt = new GestureDetector(SingleApp.getApplicationContext(), new GestureListener());

        layoutInflater = getLayoutInflater(savedInstanceState);
        bottomSheet = (BottomSheet) rootView.findViewById(R.id.bottomsheet);
        sheetView = layoutInflater.inflate(R.layout.bottom_sheet_view, bottomSheet, false);
        bottomSheet.addView(sheetView);



        findClubsButton = (LinearLayout) rootView.findViewById(R.id.find_clubs_button);
        findClubsButton.setVisibility(View.GONE);
        findClubsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SingleApp.getClubs().size() == 0)
                    loadClubs();
                if (mapIsReady)
                    updateView(mMap.getCameraPosition().target);
                showClubsButton = false;
                findClubsButton.setVisibility(View.GONE);
            }
        });

       FloatingActionButton fab = (FloatingActionButton) rootView.findViewById(R.id.fab);


        Drawable normalDrawable = getResources().getDrawable(R.drawable.ic_my_location_black_48dp);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, getResources().getColor(com.legreenfee.legreenfeesdk.R.color.grey));
        fab.setImageDrawable(wrapDrawable);
        fab.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.white)));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mapIsReady){
                    if(SingleApp.currentLocation == null)
                        managePermissionsAndActivateLocation();
                    showClubsButton = false;
                    findClubsButton.setVisibility(View.GONE);
                    if(SingleApp.currentLocation != null)
                        updateView(null);
                }
            }
        });


        mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this).build();
        mGoogleApiClient.connect();


        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        mapIsReady = true;
        mMap = googleMap;
        mMap.getUiSettings().setMapToolbarEnabled(false);
        mMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(CameraPosition cameraPosition) {
                if (!showClubsButton)
                    showClubsButton = true;
                else
                      findClubsButton.setVisibility(View.GONE);
                 //   findClubsButton.setVisibility(View.VISIBLE);
            }
        });
        MyGreenFeeKit.init(getContext(), "EC176F2D-8E7A-464A-9579-53F45AFB147B ");
        loadClubs();
        mMap.setOnMarkerClickListener(this);
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(false);


    }

    private void loadClubs() {
        markers.clear();
        mMap.clear();
        getClubsCallBack = new LGFFSDKCallBack<Void, ArrayList<LGFFClub>>() {
            @Override
            public Void onResponse(ArrayList<LGFFClub> clubs) {
                loadingLayout.setVisibility(View.GONE);
                SingleApp.setClubs(clubs);
                updateView(null);
                return null;
            }

            @Override
            public void onError(LGFFError error) {


                loadingLayout.setVisibility(View.GONE);
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                builder.setPositiveButton(R.string.Retry, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        LGFFClub.getClubs(getContext(), getClubsCallBack);
                        loadingLayout.setVisibility(View.VISIBLE);
                    }
                }).setTitle(R.string.an_error_occurred);
                if (error != null) {
                    if (error.msg != null)
                        builder.setMessage(error.msg);
                }

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        };

        LGFFClub.getClubs(getContext(), getClubsCallBack);
        loadingLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onMarkerClick(Marker arg0) {
        showClubsButton = false;
        final String clubId = arg0.getSnippet();
        selectedClubId = clubId;
        LGFFClub club = SingleApp.getClubById(clubId);
        int valueInPixels = (int) getResources().getDimension(R.dimen.bottom_sheet_height);

        TextView clubName = (TextView) sheetView.findViewById(R.id.club_name_label);
        clubName.setText(SingleApp.getClubById(clubId).name);
        Marker oldRef = null;
        Marker newRef = null;



        for(Marker m : markers) {

            if(m.getSnippet().equals(clubId)) {
                oldRef = m;
                arg0.remove();

                newRef = mMap.addMarker(new MarkerOptions().position(new LatLng(club.lat, club.lng)).icon(BitmapDescriptorFactory.fromBitmap(resizeMapIcons(R.drawable.map_pin, 1))).snippet(club.clubID));
            }

            else
                m.setIcon(BitmapDescriptorFactory.fromBitmap(resizeMapIcons(R.drawable.map_pin, 0.8)));
        }
        if(oldRef != null)
            markers.remove(oldRef);
        if(newRef != null)
            markers.add(newRef);

        LinearLayout bottomsheetButton = (LinearLayout) sheetView.findViewById(R.id.bottomsheet_button);
        bottomsheetButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(final View view, final MotionEvent event) {
                gdt.onTouchEvent(event);
                return false;
            }
        });

        bottomsheetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), ClubDetailActivity.class);
                Bundle b = new Bundle();
                b.putString("club_id", clubId); //Your id
                intent.putExtras(b); //Put your id to your next Intent
                getActivity().startActivityForResult(intent, MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE);
            }
        });
        LinearLayout fabBook = (LinearLayout) sheetView.findViewById(R.id.fab_book);
        fabBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LGFFBookingDelegate delegate = new LGFFBookingDelegate() {


                    @Override
                    public LGFFUserInfo getUserInfo() {
                        return SingleApp.loadUserInfo(SingleApp.getApplicationContext());
                    }

                    @Override
                    public void onBookingFailled(Context context, LGFFError error, Runnable reloadUserCallBack) {

                        if (error.kind != LGFFError.networkError) {
                            UserFormManager.setReloadUserInfo(reloadUserCallBack);
                            UserFormManager.setError(error);
                            if (!UserFormManager.isUserFormActivityLaunched()) {
                                Intent intent = new Intent(context, UserFormActivity.class);
                                context.startActivity(intent);

                            } else {
                                Message msg = new Message();
                                msg.what = UserFormManager.MSG_FAIL;
                                UserFormManager.getUserInfoActivityHandler().sendMessage(msg);
                            }
                        }

                    }

                    @Override
                    public void onUserInfoAccepted() {
                        if (UserFormManager.isUserFormActivityLaunched()) {
                            Message msg = new Message();
                            msg.what = UserFormManager.MSG_SUCCESS;
                            UserFormManager.getUserInfoActivityHandler().sendMessage(msg);
                        }

                    }

                    @Override
                    public void onBookingSucess(LGFFOrder order, String transactionID) {
                        if(order != null)
                            SingleApp.addOrder(order, getContext());
                    }
                };

                MyGreenFeeKit.startBookingActivity(getActivity(), SingleApp.getClubById(clubId), delegate);
            }
        });

        bottomSheet.show();
        return false;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected()) {
                LocationServices.FusedLocationApi.removeLocationUpdates(
                        mGoogleApiClient, this);
            }
        }
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();

    }


    @Override
    public void onResume() {
        super.onResume();

        mapView.onResume();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {


        ((MainActivity) getActivity()).setActionBarTitle(null);
        menu.clear();
        inflater.inflate(R.menu.main, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //Log.d("fragment_test", "################onOptionsItemSelected#################");
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_search_launcher) {
          //  Log.d("fragment_test", "################search action item selected##################");
            Fragment fragment = new ClubListFragment();
            getActivity().getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, fragment).addToBackStack(null).commit();
            return false;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onConnected(Bundle bundle) {

        managePermissionsAndActivateLocation();
    }

    private void managePermissionsAndActivateLocation(){
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(30 * 1000);
        mLocationRequest.setFastestInterval(5 * 1000);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        builder.setAlwaysShow(true);

        result = LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, builder.build());

        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                //final LocationSettingsStates state = result.getLocationSettingsStates();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:

                        if (ContextCompat.checkSelfPermission(getActivity(),
                                Manifest.permission.ACCESS_FINE_LOCATION)
                                != PackageManager.PERMISSION_GRANTED) {

                            // Should we show an explanation?
                            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                                ActivityCompat.requestPermissions(getActivity(),
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_ACCESS_LOCATION);


                            } else {

                                // No explanation needed, we can request the permission.

                                ActivityCompat.requestPermissions(getActivity(),
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_ACCESS_LOCATION);

                                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                                // app-defined int constant. The callback method gets the
                                // result of the request.
                            }
                        } else
                            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, MapFragment.this);
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        // Location settings are not satisfied. But could be fixed by showing the user
                        // a dialog.
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(
                                    getActivity(),
                                    REQUEST_LOCATION);
                        } catch (IntentSender.SendIntentException e) {
                            // Ignore the error.
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        // Location settings are not satisfied. However, we have no way to fix the
                        // settings so we won't show the dialog.
                        //...
                        break;
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    mMap.setMyLocationEnabled(true);
                    LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, MapFragment.this);

                } else {


                }
                return;
            }


        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Log.d("onActivityResult()", Integer.toString(resultCode));

        //final LocationSettingsStates states = LocationSettingsStates.fromIntent(data);
        switch (requestCode) {
            case REQUEST_LOCATION:
                switch (resultCode) {
                    case Activity.RESULT_OK: {
                        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(),
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                    MY_PERMISSIONS_REQUEST_ACCESS_LOCATION);

                            return;
                        }
                        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, MapFragment.this);

                        break;
                    }
                    case Activity.RESULT_CANCELED: {
                        // The user was asked to change settings, but chose not to

                        break;
                    }
                    default: {
                        break;
                    }
                }
                break;
        }
    }


    public Bitmap resizeMapIcons(int iconId, double factor){
        Bitmap imageBitmap = BitmapFactory.decodeResource(getResources(), iconId);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(imageBitmap, (int)Math.round(imageBitmap.getWidth() * factor), (int)Math.round(imageBitmap.getHeight() * factor), false);
        if (resizedBitmap != imageBitmap && imageBitmap.isRecycled() == false){
            imageBitmap.recycle();
        }
        return resizedBitmap;
    }


    private void updateView(LatLng target) {
        //if target == null, use current user location

        if(markers.size() == 0){
            for (LGFFClub club : SingleApp.getClubs()) {
                markers.add(mMap.addMarker(new MarkerOptions().position(new LatLng(club.lat, club.lng)).icon(BitmapDescriptorFactory.fromBitmap(resizeMapIcons(R.drawable.map_pin, 0.8))).snippet(club.clubID)));
            }
        }

        Location position = new Location("target");
        if (target != null) {
            position.setLatitude(target.latitude);
            position.setLongitude(target.longitude);
            position.setTime(new Date().getTime());
        } else {
            position = SingleApp.currentLocation;
        }

        if (position != null) {
            ArrayList<LGFFClub> nearbyGolfList = SingleApp.getNearbyClubs(position, 10);


          /*  for (LGFFClub club : nearbyGolfList) {
                mMap.addMarker(new MarkerOptions().position(new LatLng(club.lat, club.lng)).icon(BitmapDescriptorFactory.fromResource(R.drawable.map_pin)).snippet(club.clubID));
            }*/


            double maxLat;
            double maxLon;
            if (nearbyGolfList.size() > 0) {
                maxLat = nearbyGolfList.get(nearbyGolfList.size() - 1).lat;
                maxLon = nearbyGolfList.get(nearbyGolfList.size() - 1).lng;


                Point centerPoint = mMap.getProjection().toScreenLocation(new LatLng(position.getLatitude(), position.getLongitude()));
                Point furtherPoint = mMap.getProjection().toScreenLocation(new LatLng(maxLat, maxLon));
                Point origin = new Point((centerPoint.x - Math.abs(centerPoint.x - furtherPoint.x)),
                        (centerPoint.y - Math.abs(centerPoint.y - furtherPoint.y)));
                Point size = new Point(origin.x + 2 * (Math.abs(centerPoint.x - furtherPoint.x)), origin.y + 2
                        * (Math.abs(centerPoint.y - furtherPoint.y)));

                LatLng NW;
                LatLng SE;

                NW = mMap.getProjection().fromScreenLocation(origin);
                SE = mMap.getProjection().fromScreenLocation(size);

                LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
                boundsBuilder.include(NW);
                boundsBuilder.include(SE);
                final LatLngBounds bounds = boundsBuilder.build();


                if (mapIsReady)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100));

            }
        } else {

        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }


    @Override
    public void onLocationChanged(Location location) {
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        SingleApp.currentLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (SingleApp.currentLocation != null)
            LocationServices.FusedLocationApi.removeLocationUpdates(
                    mGoogleApiClient, this);
        showClubsButton = false;
        updateView(null);
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
//            throw new RuntimeException(context.toString()
            //                  + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            if(e1.getY() > e2.getY() && newScroll) {
                newScroll = false;
                Intent intent = new Intent(getActivity(), ClubDetailActivity.class);
                Bundle b = new Bundle();
                b.putString("club_id", selectedClubId); //Your id
                intent.putExtras(b); //Put your id to your next Intent
                getActivity().startActivityForResult(intent, MyGreenFeeKit.BOOKING_SUCCES_ACTIVITY_RESULT_CODE);

            }


            return true;

        }


        @Override
        public boolean onDown(MotionEvent e) {
            newScroll = true;
            return false;
        }

    }
}

