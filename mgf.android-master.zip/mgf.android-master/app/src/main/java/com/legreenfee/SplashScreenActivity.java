package com.legreenfee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.legreenfee.legreenfeesdk.LGFFPaymentActivity;

public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        final TaskDelayer taskDelayer = new TaskDelayer(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                SplashScreenActivity.this.startActivity(intent);
                finish();
            }
        }, 1000);


        taskDelayer.startDelayedTask();
        findViewById(R.id.splash_layout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskDelayer.stopDelayedTask();
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                SplashScreenActivity.this.startActivity(intent);
                finish();
            }
        });
    }
}
