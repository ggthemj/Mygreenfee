package com.legreenfee;

import android.os.Handler;

import com.legreenfee.legreenfeesdk.LGFFError;

/**
 * Created by user on 22/02/2016.
 */
public class UserFormManager {
    private static Runnable reloadUserInfo;
    private static Handler UserInfoActivityHandler;



    private static LGFFError error;

    public static final int MSG_SUCCESS = 42;
    public static final int MSG_FAIL = 43;

    public static Runnable getReloadUserInfo() {
        return reloadUserInfo;
    }

    public static void setReloadUserInfo(Runnable reloadUserInfo) {
        UserFormManager.reloadUserInfo = reloadUserInfo;
    }

    public static Handler getUserInfoActivityHandler() {
        return UserInfoActivityHandler;
    }

    public static void setUserInfoActivityHandler(Handler userInfoActivityHandler) {
        UserInfoActivityHandler = userInfoActivityHandler;
    }

    public static LGFFError getError() {
        return error;
    }

    public static void setError(LGFFError error) {
        UserFormManager.error = error;
    }

    public static boolean isUserFormActivityLaunched(){
        if(UserInfoActivityHandler != null)
            return true;
        return false;
    }
}
