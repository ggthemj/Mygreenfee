package com.legreenfee;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;


public class ReservationFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private ReservationAdapter mAdapter;
    private LinearLayout emptyLayout;



    public ReservationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        setHasOptionsMenu(true);
        View rootView = inflater.inflate(R.layout.reservation_fragment, container, false);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);

        mLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);


        mAdapter = new ReservationAdapter(SingleApp.getRecentOrders(SingleApp.getApplicationContext()), SingleApp.getApplicationContext());
        mAdapter.setOnItemClickListener(new ReservationAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {

            }
        });
        mRecyclerView.setAdapter(mAdapter);


        emptyLayout = (LinearLayout)rootView.findViewById(R.id.empty_layout);
        if(mAdapter.getItemCount() == 0)
            emptyLayout.setVisibility(View.VISIBLE);
        else
            emptyLayout.setVisibility(View.GONE);


        return rootView;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }








    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        ((MainActivity)getActivity()).setActionBarTitle(null);
    }


}
