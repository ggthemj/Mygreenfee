package com.legreenfee;

import android.os.Handler;

// Wrap Handler in order to post delayed tasks
// It ensures to have only one task
public class TaskDelayer {

    private static final int DELAY = 5 * 100; // 0,5 secs
    private int mDelay;
    private boolean mIsStarted;
    private boolean sleep;
    private Handler mHandler;
    private Runnable mRun;


    public TaskDelayer(Runnable run) {
        this(run, DELAY);
    }

    public TaskDelayer(Runnable run, int delay) {
        mHandler = new Handler();
        mIsStarted = false;
        sleep = false;
        this.mRun = run;
        mDelay = delay;
    }

    private Runnable mTask = new Runnable() {
        @Override
        public void run() {
            if (isFutureTaskAllowed()) {
                if (mIsStarted) {
                    mIsStarted = false;
                    mRun.run();
                }
            }
        }
    };

    public void startDelayedTask() {
        if (isFutureTaskAllowed()) {
            if (mIsStarted == false) {
                mIsStarted = true;
                mHandler.postDelayed(mTask, mDelay);
            }
        }
    }

    public void stopDelayedTask() {
        if (mIsStarted) {
            mHandler.removeCallbacks(mTask);
            mIsStarted = false;
        }
    }

    public void preventFutureTasks() {
        if (mIsStarted) {
            stopDelayedTask();
        }
        sleep = true;
    }

    public void allowFutureTasks() {
        sleep = false;
    }

    public boolean isFutureTaskAllowed() {
        return sleep == false;
    }
}
