package com.legreenfee;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.InputType;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.legreenfee.legreenfeesdk.LGFFUserInfo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AccountFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class AccountFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    private Date selectedDate;
    private DatePickerDialog dateDialog;
    private EditText birdthday_edit_text;
    private EditText name_edit_text;
    private EditText first_name_edit_text;
    private EditText email_edit_text;
    private EditText phone_edit_text;
    private Locale currentLocale;

    public AccountFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.account_fragment, container, false);
        ((TextView) v.findViewById(R.id.legal_label)).setMovementMethod(LinkMovementMethod.getInstance());
        ((TextView) v.findViewById(R.id.cgv_label)).setMovementMethod(LinkMovementMethod.getInstance());



        setHasOptionsMenu(true);
        getActivity().invalidateOptionsMenu();

         name_edit_text = (EditText)v.findViewById(R.id.name_edit_text);;
        first_name_edit_text = (EditText)v.findViewById(R.id.first_name_edit_text);;
        email_edit_text = (EditText)v.findViewById(R.id.email_edit_text);;
        phone_edit_text = (EditText)v.findViewById(R.id.phone_edit_text);;
        birdthday_edit_text = (EditText)v.findViewById(R.id.birdthday_edit_text);

        LGFFUserInfo user = SingleApp.loadUserInfo(SingleApp.getApplicationContext());
        if(user != null){
            name_edit_text.setText(user.getLastName());
            first_name_edit_text.setText(user.getFirstName());
            email_edit_text.setText(user.getEmail());
            phone_edit_text.setText(user.getPhone());
            setDateText(user.getBirthDate());
        }




        birdthday_edit_text.setCursorVisible(false);
        birdthday_edit_text.setInputType(InputType.TYPE_NULL);

        Calendar newCalendar = Calendar.getInstance();
        dateDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                selectedDate = newDate.getTime();
                setDateText(newDate.getTime());

            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        birdthday_edit_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dateDialog.show();
            }
        });
        birdthday_edit_text.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus) {
                    if(!dateDialog.isShowing())
                        dateDialog.show();
                }
            }
        });
        return v;


    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
//            throw new RuntimeException(context.toString()
  //                  + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        hideSoftKeyboard(getActivity());
    }

    @Override
    public void onDetach() {

        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        ((MainActivity)getActivity()).setActionBarTitle(getString(R.string.Account));
        menu.clear();
        inflater.inflate(R.menu.account_menu, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        //noinspection SimplifiableIfStatement
        if (id == R.id.save_action) {
            LGFFUserInfo user = new LGFFUserInfo();
            if(first_name_edit_text.getText() != null)
                user.setFirstName(first_name_edit_text.getText().toString());
            if(name_edit_text.getText() != null)
                user.setLastName(name_edit_text.getText().toString());
            if(email_edit_text.getText() != null)
                user.setEmail(email_edit_text.getText().toString());
            if(phone_edit_text.getText() != null)
                user.setPhone(phone_edit_text.getText().toString());
            if(selectedDate!= null)
                user.setBirthDate(selectedDate);
            SingleApp.saveUserInfo(user, SingleApp.getApplicationContext());
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View layout = inflater.inflate(R.layout.custom_toast_view,
                    (ViewGroup) getActivity().findViewById(R.id.toast_layout_root));

            TextView text = (TextView) layout.findViewById(R.id.text);
            text.setText(R.string.saved);

            Toast toast = new Toast(getContext());
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.setView(layout);
            toast.show();
            hideSoftKeyboard(getActivity());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    private void setDateText(Date date) {
        if(date != null) {
        currentLocale = getResources().getConfiguration().locale;
        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", currentLocale);
        birdthday_edit_text.setText( dateFormatter.format(date.getTime()));
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }
}
